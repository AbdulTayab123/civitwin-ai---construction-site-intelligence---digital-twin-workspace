import React, { useState } from 'react';
import {
  Upload,
  Sparkles,
  AlertTriangle,
  CheckCircle2,
  HelpCircle,
  ShieldAlert,
  ShieldCheck,
  Camera,
  Layers,
  ArrowRight,
  RefreshCw,
  PlusCircle,
  FileCheck,
  Eye,
  Info
} from 'lucide-react';
import { Project, SiteImageFinding, RiskIssue } from '../types';
import { SAMPLE_SITE_IMAGES } from '../data/sampleProject';

interface AIImageReviewProps {
  project: Project;
  onAttachFindingAsIssue: (issue: Partial<RiskIssue>) => void;
  onSaveFindingRecord: (finding: SiteImageFinding) => void;
}

export const AIImageReview: React.FC<AIImageReviewProps> = ({
  project,
  onAttachFindingAsIssue,
  onSaveFindingRecord,
}) => {
  const [selectedSampleId, setSelectedSampleId] = useState<string>(SAMPLE_SITE_IMAGES[0].id);
  const [activeImageSrc, setActiveImageSrc] = useState<string>(SAMPLE_SITE_IMAGES[0].url);
  const [activeImageTitle, setActiveImageTitle] = useState<string>(SAMPLE_SITE_IMAGES[0].title);
  const [customPromptNote, setCustomPromptNote] = useState<string>('');
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisError, setAnalysisError] = useState<string | null>(null);
  const [activeFinding, setActiveFinding] = useState<SiteImageFinding | null>(null);
  const [attachedIssueTitles, setAttachedIssueTitles] = useState<string[]>([]);
  const [uploadSuccessToast, setUploadSuccessToast] = useState<string | null>(null);

  // Initialize with sample 0 findings on mount
  React.useEffect(() => {
    loadSample(SAMPLE_SITE_IMAGES[0]);
  }, []);

  const loadSample = (sample: typeof SAMPLE_SITE_IMAGES[0]) => {
    setSelectedSampleId(sample.id);
    setActiveImageSrc(sample.url);
    setActiveImageTitle(sample.title);
    setAnalysisError(null);

    const finding: SiteImageFinding = {
      id: `sample-find-${sample.id}`,
      timestamp: new Date().toISOString(),
      imageUrl: sample.url,
      imageTitle: sample.title,
      projectName: project.name,
      activePhase: sample.phase,
      sufficientEvidence: sample.mockFindings.sufficientEvidence,
      siteConditionSummary: sample.mockFindings.siteConditionSummary,
      visibleWork: sample.mockFindings.visibleWork,
      visibleMaterials: sample.mockFindings.visibleMaterials,
      potentialIssues: sample.mockFindings.potentialIssues as SiteImageFinding['potentialIssues'],
      uncertaintyDisclaimer: sample.mockFindings.uncertaintyDisclaimer,
      platformNotice: sample.mockFindings.platformNotice,
    };
    setActiveFinding(finding);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    if (!file.type.startsWith('image/')) {
      setAnalysisError('Please upload a valid image file (JPEG, PNG, WebP).');
      return;
    }

    const reader = new FileReader();
    reader.onload = () => {
      const result = reader.result as string;
      setActiveImageSrc(result);
      setActiveImageTitle(file.name);
      setSelectedSampleId('custom-upload');
      setAnalysisError(null);
      // Trigger AI analysis on the uploaded image
      triggerGeminiAnalysis(result, file.name);
    };
    reader.readAsDataURL(file);
  };

  const triggerGeminiAnalysis = async (imgDataUrl: string, title: string) => {
    setIsAnalyzing(true);
    setAnalysisError(null);
    setAttachedIssueTitles([]);

    try {
      const response = await fetch('/api/analyze-site-image', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          imageBase64: imgDataUrl,
          mimeType: imgDataUrl.startsWith('data:image/png') ? 'image/png' : 'image/jpeg',
          projectName: project.name,
          currentPhase: project.activePhase,
          promptContext: customPromptNote,
        }),
      });

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        throw new Error(errorData.error || `Server responded with status ${response.status}`);
      }

      const data = await response.json();
      const newFinding: SiteImageFinding = {
        id: `finding-${Date.now()}`,
        timestamp: new Date().toISOString(),
        imageUrl: imgDataUrl,
        imageTitle: title,
        projectName: project.name,
        activePhase: project.activePhase,
        sufficientEvidence: data.sufficientEvidence ?? true,
        siteConditionSummary: data.siteConditionSummary || 'Inspection completed.',
        visibleWork: data.visibleWork || [],
        visibleMaterials: data.visibleMaterials || [],
        potentialIssues: data.potentialIssues || [],
        uncertaintyDisclaimer:
          data.uncertaintyDisclaimer ||
          'Visual inspection only. Structural integrity and materials grade must be verified by a licensed engineer.',
        platformNotice:
          data.platformNotice ||
          'CiviTwin AI is an advisory planning tool and does not certify structural compliance.',
      };

      setActiveFinding(newFinding);
      onSaveFindingRecord(newFinding);
      showToast('AI Site Analysis successfully completed');
    } catch (err: any) {
      console.warn('Live Gemini API call failed or offline:', err);
      setAnalysisError(
        `Gemini API request note: ${err.message}. Showing comprehensive visual inspection guidelines.`
      );
      // If server doesn't have an active key, provide a clean fall-back evaluation without inventing false results
      if (!activeFinding) {
        loadSample(SAMPLE_SITE_IMAGES[0]);
      }
    } finally {
      setIsAnalyzing(false);
    }
  };

  const showToast = (msg: string) => {
    setUploadSuccessToast(msg);
    setTimeout(() => setUploadSuccessToast(null), 4000);
  };

  const handleAttachIssue = (issue: any) => {
    if (attachedIssueTitles.includes(issue.title)) return;

    onAttachFindingAsIssue({
      title: issue.title,
      category: issue.category || 'workmanship',
      severity: issue.severity || 'medium',
      description: issue.description,
      location: issue.locationHint || `${project.name} Active Workface`,
      assignedTo: 'Lead QA/QC Site Engineer',
      dueDate: new Date(Date.now() + 5 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'open',
      source: 'ai_image_finding',
      evidenceImageUrl: activeImageSrc,
      requiresPEVerification: issue.requiresEngineerVerification ?? true,
      aiSuggestedAction: issue.uncertaintyNote
        ? `Physical verification requirement: ${issue.uncertaintyNote}`
        : 'Conduct on-site physical measurement before signature.',
    });

    setAttachedIssueTitles((prev) => [...prev, issue.title]);
    showToast(`Issue "${issue.title}" logged in Project Risk Register`);
  };

  return (
    <div className="flex flex-col h-full space-y-4">
      {/* Toast Notification */}
      {uploadSuccessToast && (
        <div className="fixed bottom-5 right-5 z-50 bg-[#0e1726] border border-cyan-500/70 text-cyan-200 px-4 py-2.5 rounded-xl shadow-2xl flex items-center gap-2 text-xs font-mono animate-in slide-in-from-bottom-2">
          <CheckCircle2 className="w-4 h-4 text-cyan-400" />
          <span>{uploadSuccessToast}</span>
        </div>
      )}

      {/* Mandatory Engineering Governance Banner */}
      <div className="bg-amber-950/30 border border-amber-600/40 rounded-xl p-3 flex items-start gap-3 text-xs text-amber-200/90">
        <ShieldAlert className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div className="space-y-0.5">
          <div className="font-semibold text-amber-300 font-mono uppercase tracking-wider text-[11px]">
            Statutory Civil Engineering Disclaimer & Operating Boundary
          </div>
          <p className="text-[11px] leading-relaxed text-amber-200/80">
            CiviTwin AI is an advisory planning and digital twin decision-support system. It does
            <strong> NOT</strong> certify structural calculations, concrete compressive strength,
            rebar yield stress, soil bearing capacity, or code compliance. All findings are visual
            observations and require physical on-site inspection by a licensed Professional Engineer (PE / SE).
          </p>
        </div>
      </div>

      {/* Split-screen Workspace: Left Site Image / Upload - Right AI Findings */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1">
        {/* LEFT COLUMN: Site Image & Controls (5 cols) */}
        <div className="lg:col-span-5 flex flex-col space-y-3">
          {/* Image Display & Preview Card */}
          <div className="bg-[#0d131f] border border-slate-800 rounded-xl overflow-hidden shadow-xl flex flex-col flex-1">
            <div className="p-3 border-b border-slate-800/80 bg-[#0e1627]/60 flex items-center justify-between">
              <div className="flex items-center gap-2">
                <Camera className="w-4 h-4 text-cyan-400" />
                <span className="text-xs font-semibold text-slate-200 font-mono truncate max-w-[220px]">
                  {activeImageTitle}
                </span>
              </div>
              <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400">
                FRAME INSPECTION
              </span>
            </div>

            {/* Image Preview Container */}
            <div className="relative w-full h-64 sm:h-80 bg-slate-950 flex items-center justify-center overflow-hidden group">
              <img
                src={activeImageSrc}
                alt={activeImageTitle}
                className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.02]"
              />

              {/* Grid overlay for architectural feel */}
              <div className="absolute inset-0 bg-blueprint-grid opacity-25 pointer-events-none" />

              {/* Status Tag on Image */}
              <div className="absolute bottom-2 left-2 z-10 flex items-center gap-1.5 px-2.5 py-1 rounded-md bg-[#080e18]/85 border border-cyan-500/50 backdrop-blur-md text-[10px] font-mono text-cyan-300">
                <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 animate-pulse"></span>
                <span>Active Workface: {project.activePhase.toUpperCase()}</span>
              </div>

              {isAnalyzing && (
                <div className="absolute inset-0 bg-[#080e18]/85 backdrop-blur-sm flex flex-col items-center justify-center gap-3 z-20">
                  <RefreshCw className="w-8 h-8 text-cyan-400 animate-spin" />
                  <div className="text-xs font-mono text-cyan-200">
                    Querying Gemini 3.8 Flash Vision Model...
                  </div>
                  <div className="text-[10px] text-slate-400">
                    Evaluating visible elements, materials & anomalies
                  </div>
                </div>
              )}
            </div>

            {/* Upload & Re-run Toolbar */}
            <div className="p-3 bg-slate-950/60 border-t border-slate-800 space-y-2.5">
              <div className="flex items-center gap-2">
                {/* File Upload Input */}
                <label className="flex-1 flex items-center justify-center gap-2 px-3 py-2 rounded-lg bg-cyan-500/10 border border-cyan-500/40 hover:bg-cyan-500/20 text-cyan-300 text-xs font-mono cursor-pointer transition-all">
                  <Upload className="w-3.5 h-3.5" />
                  <span>Upload Site Photo</span>
                  <input
                    type="file"
                    accept="image/*"
                    onChange={handleFileUpload}
                    className="hidden"
                  />
                </label>

                {/* Re-analyze Button */}
                <button
                  disabled={isAnalyzing}
                  onClick={() => triggerGeminiAnalysis(activeImageSrc, activeImageTitle)}
                  className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono transition-all disabled:opacity-50"
                >
                  <RefreshCw className={`w-3.5 h-3.5 ${isAnalyzing ? 'animate-spin' : ''}`} />
                  <span>Re-Analyze</span>
                </button>
              </div>

              {/* Sample Photo Preset Selector */}
              <div>
                <div className="text-[10px] uppercase font-mono text-slate-400 mb-1.5">
                  Demonstration Inspection Samples:
                </div>
                <div className="grid grid-cols-3 gap-1.5">
                  {SAMPLE_SITE_IMAGES.map((sample) => (
                    <button
                      key={sample.id}
                      onClick={() => loadSample(sample)}
                      className={`text-left p-1.5 rounded-lg border text-[10px] font-mono transition-all truncate ${
                        selectedSampleId === sample.id
                          ? 'bg-cyan-950/80 border-cyan-500 text-cyan-300'
                          : 'bg-slate-900 border-slate-800 text-slate-400 hover:text-slate-200'
                      }`}
                    >
                      {sample.phase.toUpperCase()}: {sample.title.split(' ')[0]}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* RIGHT COLUMN: AI Findings & Evidence Registry (7 cols) */}
        <div className="lg:col-span-7 flex flex-col space-y-3">
          <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl flex-1 flex flex-col">
            {/* Header */}
            <div className="flex items-center justify-between pb-3 border-b border-slate-800">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-cyan-400" />
                <h3 className="text-sm font-semibold text-slate-100 font-mono uppercase">
                  AI Visual Findings & Observations
                </h3>
              </div>
              <div className="flex items-center gap-2">
                <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950/80 border border-emerald-800 text-emerald-400">
                  GEMINI 3.8 FLASH
                </span>
              </div>
            </div>

            {analysisError && (
              <div className="mt-3 p-3 rounded-lg bg-slate-900/90 border border-slate-700 text-xs text-slate-300 flex items-start gap-2">
                <Info className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
                <div>
                  <div className="font-semibold text-slate-200">Analysis Note</div>
                  <p className="text-[11px] text-slate-400">{analysisError}</p>
                </div>
              </div>
            )}

            {activeFinding ? (
              <div className="mt-3 space-y-4 overflow-y-auto max-h-[600px] pr-1">
                {/* 1. Technical Summary */}
                <div className="p-3 rounded-lg bg-slate-900/60 border border-slate-800 space-y-1">
                  <div className="text-[10px] uppercase font-mono text-slate-400">
                    Site Condition Overview
                  </div>
                  <p className="text-xs text-slate-200 leading-relaxed font-sans">
                    {activeFinding.siteConditionSummary}
                  </p>
                </div>

                {/* 2. Visible Work Operations */}
                <div>
                  <div className="text-[10px] uppercase font-mono text-cyan-400 mb-1.5 flex items-center gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5" />
                    <span>Identified Operations & Progress</span>
                  </div>
                  <div className="space-y-1.5">
                    {activeFinding.visibleWork.map((work, idx) => (
                      <div
                        key={idx}
                        className="flex items-start gap-2 p-2 rounded-lg bg-slate-900/40 border border-slate-800/80 text-xs text-slate-300"
                      >
                        <span className="text-cyan-400 font-mono text-[11px] mt-0.5">•</span>
                        <span>{work}</span>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 3. Visible Materials & Equipment */}
                <div>
                  <div className="text-[10px] uppercase font-mono text-cyan-400 mb-1.5 flex items-center gap-1.5">
                    <Layers className="w-3.5 h-3.5" />
                    <span>Materials & Equipment Inventory</span>
                  </div>
                  <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
                    {activeFinding.visibleMaterials.map((mat, idx) => (
                      <div
                        key={idx}
                        className="p-2.5 rounded-lg bg-slate-900/60 border border-slate-800 text-xs flex flex-col justify-between space-y-1.5"
                      >
                        <div className="flex items-start justify-between">
                          <span className="font-semibold text-slate-200">{mat.name}</span>
                          <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-800 text-cyan-400">
                            {mat.confidence}% conf
                          </span>
                        </div>
                        <div className="flex items-center justify-between text-[11px] font-mono text-slate-400">
                          <span className="capitalize text-slate-300">Status: {mat.status}</span>
                          {mat.estimatedQuantity && (
                            <span className="text-amber-300/90">{mat.estimatedQuantity}</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                </div>

                {/* 4. Potential Issues & Human Review Checklist */}
                <div>
                  <div className="text-[10px] uppercase font-mono text-amber-400 mb-1.5 flex items-center justify-between">
                    <div className="flex items-center gap-1.5">
                      <AlertTriangle className="w-3.5 h-3.5 text-amber-400" />
                      <span>Potential Items Requiring Human Engineer Review</span>
                    </div>
                    <span className="text-slate-500 font-normal">
                      {activeFinding.potentialIssues.length} flagged
                    </span>
                  </div>

                  <div className="space-y-2">
                    {activeFinding.potentialIssues.map((issue, idx) => {
                      const isAttached = attachedIssueTitles.includes(issue.title);
                      return (
                        <div
                          key={idx}
                          className="p-3 rounded-lg bg-[#111928] border border-amber-900/40 space-y-2 hover:border-amber-700/60 transition-all"
                        >
                          <div className="flex items-start justify-between gap-2">
                            <div className="space-y-0.5">
                              <div className="flex items-center gap-2">
                                <span
                                  className={`text-[9px] font-mono uppercase px-1.5 py-0.5 rounded ${
                                    issue.severity === 'high'
                                      ? 'bg-red-950 text-red-300 border border-red-800'
                                      : 'bg-amber-950 text-amber-300 border border-amber-800'
                                  }`}
                                >
                                  {issue.severity}
                                </span>
                                <span className="text-xs font-semibold text-slate-200">
                                  {issue.title}
                                </span>
                              </div>
                              <p className="text-[11px] text-slate-300 leading-relaxed">
                                {issue.description}
                              </p>
                            </div>

                            {/* Attach to Risk Register action button */}
                            <button
                              onClick={() => handleAttachIssue(issue)}
                              disabled={isAttached}
                              className={`flex-shrink-0 flex items-center gap-1 px-2.5 py-1.5 rounded-lg text-xs font-mono transition-all ${
                                isAttached
                                  ? 'bg-emerald-950 border border-emerald-700 text-emerald-300 cursor-default'
                                  : 'bg-cyan-500/15 hover:bg-cyan-500/25 border border-cyan-500/40 text-cyan-300'
                              }`}
                            >
                              {isAttached ? (
                                <>
                                  <FileCheck className="w-3 h-3 text-emerald-400" />
                                  <span>Logged</span>
                                </>
                              ) : (
                                <>
                                  <PlusCircle className="w-3 h-3 text-cyan-400" />
                                  <span>Log to Register</span>
                                </>
                              )}
                            </button>
                          </div>

                          {/* Uncertainty Factor Note */}
                          <div className="text-[10px] font-mono text-slate-400 bg-slate-950/60 p-1.5 rounded border border-slate-900 flex items-center justify-between">
                            <span className="text-amber-300/80">
                              Verification note: {issue.uncertaintyNote}
                            </span>
                            <span className="text-slate-500">{issue.confidence}% cert</span>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* 5. Uncertainty & Non-Certification Notice */}
                <div className="p-3 rounded-lg bg-slate-950 border border-slate-800/80 text-[11px] font-mono text-slate-400 space-y-1">
                  <div className="text-cyan-400 flex items-center gap-1.5">
                    <ShieldCheck className="w-3.5 h-3.5" />
                    <span>Inspection Limitation Factor</span>
                  </div>
                  <p>{activeFinding.uncertaintyDisclaimer}</p>
                </div>
              </div>
            ) : (
              <div className="flex-1 flex flex-col items-center justify-center text-slate-500 text-xs">
                Select an inspection sample or upload a photo to view AI visual findings.
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
