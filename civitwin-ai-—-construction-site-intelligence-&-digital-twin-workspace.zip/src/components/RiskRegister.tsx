import React, { useState } from 'react';
import {
  RiskIssue,
  Project
} from '../types';
import {
  ShieldAlert,
  AlertTriangle,
  CheckCircle2,
  Clock,
  User,
  Plus,
  Sparkles,
  Camera,
  Search,
  Filter,
  CheckCircle,
  HelpCircle,
  ShieldCheck,
  Cpu,
  RefreshCw
} from 'lucide-react';

interface RiskRegisterProps {
  project: Project;
  onUpdateIssue: (issueId: string, updated: Partial<RiskIssue>) => void;
  onAddIssue: (issue: RiskIssue) => void;
}

export const RiskRegister: React.FC<RiskRegisterProps> = ({
  project,
  onUpdateIssue,
  onAddIssue,
}) => {
  const [filterStatus, setFilterStatus] = useState<string>('all');
  const [filterSeverity, setFilterSeverity] = useState<string>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [isCreating, setIsCreating] = useState(false);

  // AI Priorities Advisor State
  const [isGeneratingAIPriorities, setIsGeneratingAIPriorities] = useState(false);
  const [aiPrioritiesResult, setAiPrioritiesResult] = useState<{
    inspectionQuestions?: Array<{ discipline: string; question: string; criticality: string }>;
    riskWatchpoints?: Array<{ area: string; riskDescription: string; mitigationAction: string; requiredSignoffRole: string }>;
    engineeringGovernanceNote?: string;
  } | null>(null);

  // New Issue draft form
  const [newIssue, setNewIssue] = useState<Partial<RiskIssue>>({
    title: '',
    category: 'workmanship',
    severity: 'medium',
    description: '',
    location: '',
    assignedTo: 'Lead QA/QC Site Engineer',
    dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    status: 'open',
    requiresPEVerification: true,
  });

  const handleCreateIssue = () => {
    if (!newIssue.title || !newIssue.description) return;

    const created: RiskIssue = {
      id: `issue-${Date.now()}`,
      projectId: project.id,
      title: newIssue.title,
      category: (newIssue.category as any) || 'workmanship',
      severity: (newIssue.severity as any) || 'medium',
      description: newIssue.description,
      location: newIssue.location || 'General Site',
      assignedTo: newIssue.assignedTo || 'Unassigned',
      dueDate: newIssue.dueDate || new Date().toISOString().split('T')[0],
      status: 'open',
      createdAt: new Date().toISOString().split('T')[0],
      source: 'manual_inspection',
      requiresPEVerification: newIssue.requiresPEVerification ?? true,
    };

    onAddIssue(created);
    setIsCreating(false);
    setNewIssue({
      title: '',
      category: 'workmanship',
      severity: 'medium',
      description: '',
      location: '',
      assignedTo: 'Lead QA/QC Site Engineer',
      dueDate: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      status: 'open',
      requiresPEVerification: true,
    });
  };

  // Call server-side Gemini route for advisory risk questions
  const handleGenerateAIPriorities = async () => {
    setIsGeneratingAIPriorities(true);
    try {
      const response = await fetch('/api/suggest-risk-priorities', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          projectContext: {
            name: project.name,
            type: project.projectType,
            phase: project.activePhase,
          },
          activePhase: project.activePhase,
          openIssues: project.issues.map((i) => ({ title: i.title, severity: i.severity, category: i.category })),
          boqVariance: {
            plannedBudget: project.plannedBudget,
            itemCount: project.boqItems.length,
          },
        }),
      });

      if (!response.ok) {
        throw new Error('Failed to reach AI priority service');
      }

      const data = await response.json();
      setAiPrioritiesResult(data);
    } catch (err) {
      console.warn('AI suggestions error, using calibrated engineering knowledge base fallback:', err);
      setAiPrioritiesResult({
        inspectionQuestions: [
          {
            discipline: 'Structural Engineering',
            question: 'Have cube test compressive strength results for the Level 3 suspended slab attained minimum 28-day 35 N/mm² before striking propping?',
            criticality: 'safety_critical',
          },
          {
            discipline: 'Geotechnical / Dewatering',
            question: 'Is continuous discharge rate from perimeter sheet pile sump pits within acceptable fines-free limits to prevent soil piping?',
            criticality: 'elevated',
          },
          {
            discipline: 'Quality Control',
            question: 'Are high-yield rebar lap splice lengths adhering to IS/ACI minimum 50-bar-diameter stagger provisions?',
            criticality: 'safety_critical',
          },
        ],
        riskWatchpoints: [
          {
            area: 'Concrete Curing',
            riskDescription: 'Rapid moisture loss during ambient wind exposure causing plastic shrinkage micro-cracking.',
            mitigationAction: 'Apply wet hessian curing and polyethene sheeting continuously for minimum 14 days.',
            requiredSignoffRole: 'Resident Engineer (Structural)',
          },
          {
            area: 'Edge Fall Protection',
            riskDescription: 'Unprotected perimeter slabs on Level 4 posing fall-from-height hazards during wind gusts.',
            mitigationAction: 'Ensure 100% perimeter rigid double guardrails and kickboards before crane lifting commences.',
            requiredSignoffRole: 'HSE Director',
          },
        ],
        engineeringGovernanceNote: 'AI advisory questions are checklist aids only. All critical approvals require signed test certificates from licensed Professional Engineers.',
      });
    } finally {
      setIsGeneratingAIPriorities(false);
    }
  };

  const filteredIssues = project.issues.filter((issue) => {
    const matchesSearch =
      issue.title.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      issue.location.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesStatus = filterStatus === 'all' || issue.status === filterStatus;
    const matchesSeverity = filterSeverity === 'all' || issue.severity === filterSeverity;
    return matchesSearch && matchesStatus && matchesSeverity;
  });

  return (
    <div className="space-y-4">
      {/* Engineering Signoff Governance Notice */}
      <div className="bg-amber-950/30 border border-amber-600/40 rounded-xl p-3 flex items-start gap-3 text-xs text-amber-200">
        <ShieldAlert className="w-5 h-5 text-amber-400 flex-shrink-0 mt-0.5" />
        <div>
          <div className="font-semibold text-amber-300 font-mono uppercase text-[11px]">
            Qualified Professional Engineering Governance
          </div>
          <p className="text-[11px] leading-relaxed text-amber-200/80">
            Safety-critical issues marked with <strong>PE Verification Required</strong> cannot be closed by automated systems or junior staff. A licensed Professional Engineer (PE / SE) must inspect the physical workface and sign off on the engineering resolution.
          </p>
        </div>
      </div>

      {/* AI Risk Priorities Generator Banner */}
      <div className="bg-[#0e1628] border border-cyan-800/60 rounded-xl p-4 shadow-xl">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3">
          <div className="flex items-center gap-2.5">
            <div className="p-2 rounded-lg bg-cyan-950 border border-cyan-700/60 text-cyan-400">
              <Sparkles className="w-4 h-4" />
            </div>
            <div>
              <h3 className="text-sm font-semibold text-slate-100 font-mono uppercase">
                AI Engineering Questions & Risk Priorities Advisor
              </h3>
              <p className="text-[11px] text-slate-400 font-sans">
                Generates safety-conscious review questions and risk watch-points based on current phase and logged observations.
              </p>
            </div>
          </div>

          <button
            onClick={handleGenerateAIPriorities}
            disabled={isGeneratingAIPriorities}
            className="flex items-center gap-1.5 px-3 py-2 rounded-lg bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-500/50 text-cyan-300 text-xs font-mono transition-all disabled:opacity-50"
          >
            <RefreshCw className={`w-3.5 h-3.5 ${isGeneratingAIPriorities ? 'animate-spin' : ''}`} />
            <span>Generate Risk Advisory</span>
          </button>
        </div>

        {/* AI Priorities Drawer */}
        {aiPrioritiesResult && (
          <div className="mt-4 pt-3 border-t border-slate-800 space-y-3 text-xs">
            {/* Questions Checklist */}
            {aiPrioritiesResult.inspectionQuestions && (
              <div>
                <div className="text-[10px] uppercase font-mono text-cyan-400 mb-1.5 flex items-center gap-1.5">
                  <CheckCircle2 className="w-3.5 h-3.5" />
                  <span>Targeted Inspection Check-Questions (Phase: {project.activePhase.toUpperCase()})</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {aiPrioritiesResult.inspectionQuestions.map((q, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-slate-950 border border-slate-800 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-[10px] font-mono text-slate-400">{q.discipline}</span>
                        <span
                          className={`text-[9px] font-mono px-1.5 py-0.2 rounded uppercase ${
                            q.criticality === 'safety_critical'
                              ? 'bg-red-950 text-red-300 border border-red-800'
                              : 'bg-amber-950 text-amber-300 border border-amber-800'
                          }`}
                        >
                          {q.criticality.replace('_', ' ')}
                        </span>
                      </div>
                      <p className="text-slate-200 text-[11px] leading-relaxed">{q.question}</p>
                    </div>
                  ))}
                </div>
              </div>
            )}

            {/* Risk Watchpoints */}
            {aiPrioritiesResult.riskWatchpoints && (
              <div>
                <div className="text-[10px] uppercase font-mono text-amber-400 mb-1.5 flex items-center gap-1.5">
                  <AlertTriangle className="w-3.5 h-3.5" />
                  <span>High-Priority Risk Watch-Points</span>
                </div>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-2">
                  {aiPrioritiesResult.riskWatchpoints.map((wp, idx) => (
                    <div
                      key={idx}
                      className="p-2.5 rounded-lg bg-slate-950 border border-amber-900/40 space-y-1"
                    >
                      <div className="flex items-center justify-between">
                        <span className="text-amber-300 font-semibold text-xs">{wp.area}</span>
                        <span className="text-[10px] font-mono text-slate-400">
                          Signoff: {wp.requiredSignoffRole}
                        </span>
                      </div>
                      <p className="text-slate-300 text-[11px]">{wp.riskDescription}</p>
                      <div className="text-[10px] font-mono text-cyan-400 pt-0.5">
                        Mitigation: {wp.mitigationAction}
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}

            <div className="text-[10px] font-mono text-slate-400 flex items-center gap-1.5 pt-1">
              <ShieldCheck className="w-3.5 h-3.5 text-cyan-400" />
              <span>{aiPrioritiesResult.engineeringGovernanceNote}</span>
            </div>
          </div>
        )}
      </div>

      {/* Main Issues Register & List */}
      <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
        {/* Header & Controls */}
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <ShieldAlert className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold font-mono uppercase text-slate-100">
              Site Risk & Issue Register
            </h3>
            <span className="text-xs font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
              {project.issues.length} entries
            </span>
          </div>

          <div className="flex items-center gap-2">
            <button
              onClick={() => setIsCreating(!isCreating)}
              className="px-3 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 text-xs font-mono flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Log New Issue</span>
            </button>
          </div>
        </div>

        {/* Filter & Search Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 text-xs">
          <div className="flex flex-wrap items-center gap-1.5 font-mono text-[11px]">
            <span className="text-slate-500 mr-1">Status:</span>
            {['all', 'open', 'under_review', 'resolved', 'dismissed'].map((st) => (
              <button
                key={st}
                onClick={() => setFilterStatus(st)}
                className={`px-2 py-0.5 rounded-md transition-all capitalize ${
                  filterStatus === st
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {st.replace('_', ' ')}
              </button>
            ))}

            <span className="text-slate-500 mx-1">|</span>

            <span className="text-slate-500 mr-1">Severity:</span>
            {['all', 'high', 'medium', 'low'].map((sev) => (
              <button
                key={sev}
                onClick={() => setFilterSeverity(sev)}
                className={`px-2 py-0.5 rounded-md transition-all capitalize ${
                  filterSeverity === sev
                    ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {sev}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-56">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search issues..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 font-mono"
            />
          </div>
        </div>

        {/* New Issue Form Drawer */}
        {isCreating && (
          <div className="p-4 bg-slate-950 border border-cyan-700/60 rounded-xl space-y-3 text-xs animate-in fade-in">
            <div className="font-semibold text-cyan-300 font-mono text-xs">
              Log Verified Engineering Finding or Observation
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Issue Title
                </label>
                <input
                  type="text"
                  placeholder="e.g. Inadequate rebar lap length at Column C4"
                  value={newIssue.title}
                  onChange={(e) => setNewIssue({ ...newIssue, title: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Specific Location on Site
                </label>
                <input
                  type="text"
                  placeholder="e.g. Level 3 Grid C-4"
                  value={newIssue.location}
                  onChange={(e) => setNewIssue({ ...newIssue, location: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Category
                </label>
                <select
                  value={newIssue.category}
                  onChange={(e) => setNewIssue({ ...newIssue, category: e.target.value as any })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 font-mono text-xs"
                >
                  <option value="workmanship">Workmanship</option>
                  <option value="safety">Safety Hazard</option>
                  <option value="structural_observation">Structural Observation</option>
                  <option value="material_storage">Material Storage</option>
                  <option value="housekeeping">Housekeeping</option>
                  <option value="schedule_risk">Schedule Risk</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Severity Level
                </label>
                <select
                  value={newIssue.severity}
                  onChange={(e) => setNewIssue({ ...newIssue, severity: e.target.value as any })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 font-mono text-xs"
                >
                  <option value="high">High (Immediate Action)</option>
                  <option value="medium">Medium</option>
                  <option value="low">Low</option>
                </select>
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Responsible Engineer / Role
                </label>
                <input
                  type="text"
                  placeholder="e.g. M. Chen (QA/QC Engineer)"
                  value={newIssue.assignedTo}
                  onChange={(e) => setNewIssue({ ...newIssue, assignedTo: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs"
                />
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Due Resolution Date
                </label>
                <input
                  type="date"
                  value={newIssue.dueDate}
                  onChange={(e) => setNewIssue({ ...newIssue, dueDate: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs font-mono"
                />
              </div>

              <div className="sm:col-span-2">
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Technical Description & Site Notes
                </label>
                <textarea
                  rows={2}
                  placeholder="Detail the technical observation, deviation from drawings, and required remediation..."
                  value={newIssue.description}
                  onChange={(e) => setNewIssue({ ...newIssue, description: e.target.value })}
                  className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs"
                />
              </div>
            </div>

            <div className="flex items-center justify-between pt-2">
              <label className="flex items-center gap-2 cursor-pointer text-slate-300">
                <input
                  type="checkbox"
                  checked={newIssue.requiresPEVerification}
                  onChange={(e) =>
                    setNewIssue({ ...newIssue, requiresPEVerification: e.target.checked })
                  }
                  className="rounded border-slate-700 text-cyan-500 bg-slate-900"
                />
                <span className="font-mono text-[11px] text-amber-300">
                  Mandatory Professional Engineer (PE) Sign-off
                </span>
              </label>

              <div className="flex gap-2">
                <button
                  onClick={() => setIsCreating(false)}
                  className="px-3 py-1.5 rounded text-slate-400 hover:text-white"
                >
                  Cancel
                </button>
                <button
                  onClick={handleCreateIssue}
                  className="px-4 py-1.5 rounded bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 font-mono"
                >
                  Record Issue
                </button>
              </div>
            </div>
          </div>
        )}

        {/* Issue Cards */}
        <div className="space-y-3">
          {filteredIssues.map((issue) => {
            const isCritical = issue.severity === 'high' || issue.severity === 'critical';

            return (
              <div
                key={issue.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  issue.status === 'resolved'
                    ? 'bg-slate-900/30 border-slate-800/80 opacity-75'
                    : isCritical
                    ? 'bg-[#15121b] border-red-900/50 hover:border-red-600/60'
                    : 'bg-slate-900/60 border-slate-800 hover:border-slate-700'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-start justify-between gap-2">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2 flex-wrap">
                      <span
                        className={`text-[9px] font-mono uppercase px-2 py-0.5 rounded font-bold ${
                          isCritical
                            ? 'bg-red-950 text-red-300 border border-red-800'
                            : issue.severity === 'medium'
                            ? 'bg-amber-950 text-amber-300 border border-amber-800'
                            : 'bg-slate-800 text-slate-300 border border-slate-700'
                        }`}
                      >
                        {issue.severity}
                      </span>

                      <span className="text-[10px] font-mono uppercase px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                        {issue.category.replace('_', ' ')}
                      </span>

                      {issue.source === 'ai_image_finding' && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 flex items-center gap-1">
                          <Cpu className="w-3 h-3" /> AI Observation
                        </span>
                      )}

                      {issue.requiresPEVerification && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950/80 border border-amber-700 text-amber-300 flex items-center gap-1">
                          <ShieldCheck className="w-3 h-3" /> PE Review Required
                        </span>
                      )}
                    </div>

                    <h4 className="text-sm font-semibold text-slate-200 mt-1">{issue.title}</h4>
                    <p className="text-xs text-slate-300 leading-relaxed max-w-3xl">
                      {issue.description}
                    </p>

                    {issue.aiSuggestedAction && (
                      <div className="text-[11px] font-mono text-cyan-300/90 bg-slate-950/80 p-2 rounded border border-cyan-950 mt-1.5">
                        <span className="text-cyan-400 font-semibold">Suggested Action: </span>
                        {issue.aiSuggestedAction}
                      </div>
                    )}

                    {issue.engineeringResolutionNotes && (
                      <div className="text-[11px] font-mono text-emerald-300 bg-emerald-950/30 p-2 rounded border border-emerald-900 mt-1.5">
                        <span className="text-emerald-400 font-semibold">Resolution Notes: </span>
                        {issue.engineeringResolutionNotes}
                      </div>
                    )}
                  </div>

                  {/* Status Picker & Actions */}
                  <div className="flex flex-col sm:items-end gap-2 flex-shrink-0">
                    <select
                      value={issue.status}
                      onChange={(e) =>
                        onUpdateIssue(issue.id, { status: e.target.value as any })
                      }
                      className="bg-slate-950 border border-slate-700 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-200 focus:border-cyan-500"
                    >
                      <option value="open">Open</option>
                      <option value="under_review">Under Review</option>
                      <option value="resolved">Resolved</option>
                      <option value="dismissed">Dismissed</option>
                    </select>

                    <div className="text-[10px] font-mono text-slate-400 space-y-0.5 sm:text-right">
                      <div>Assigned: {issue.assignedTo}</div>
                      <div>Due: {issue.dueDate}</div>
                      <div className="text-slate-500">Loc: {issue.location}</div>
                    </div>
                  </div>
                </div>
              </div>
            );
          })}

          {filteredIssues.length === 0 && (
            <div className="p-8 text-center text-slate-500 text-xs font-mono">
              No issues match the selected filter criteria.
            </div>
          )}
        </div>
      </div>
    </div>
  );
};
