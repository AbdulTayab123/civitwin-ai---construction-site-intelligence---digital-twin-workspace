import React from 'react';
import {
  Home,
  FolderKanban,
  Layers,
  Sparkles,
  FileText,
  ShieldAlert,
  TrendingUp,
  Cpu,
  Search,
  Bell,
  Settings,
  User,
  ShieldCheck,
  ChevronDown
} from 'lucide-react';
import { Project } from '../types';

export type NavTab = 'overview' | 'projects' | 'materials' | 'ai_analysis' | 'progress' | 'risks' | 'reports';

interface HeaderNavProps {
  currentTab: NavTab;
  onSelectTab: (tab: NavTab) => void;
  projects: Project[];
  activeProject: Project;
  onSelectProject: (id: string) => void;
  hasGeminiKey: boolean;
}

export const HeaderNav: React.FC<HeaderNavProps> = ({
  currentTab,
  onSelectTab,
  projects,
  activeProject,
  onSelectProject,
  hasGeminiKey,
}) => {
  return (
    <header className="bg-[#080d16] border-b border-slate-800/90 sticky top-0 z-40 backdrop-blur-md">
      <div className="max-w-[1720px] mx-auto px-4 py-2.5 flex items-center justify-between gap-4">
        {/* Left: Brand & Project Quick-Selector */}
        <div className="flex items-center gap-3">
          <div className="flex items-center gap-2.5">
            <div className="w-8 h-8 rounded-lg bg-gradient-to-br from-cyan-400 to-cyan-600 flex items-center justify-center text-slate-950 font-bold font-mono text-sm shadow-md glow-sm-cyan">
              CT
            </div>
            <div className="hidden sm:block">
              <div className="font-bold font-mono tracking-tight text-slate-100 text-sm flex items-center gap-1.5">
                <span>CiviTwin</span>
                <span className="text-[10px] font-mono px-1.5 py-0.2 rounded bg-cyan-950 border border-cyan-800 text-cyan-400">
                  AI
                </span>
              </div>
              <div className="text-[10px] text-slate-400 font-mono tracking-tight">
                Digital Twin & Civil Site Intelligence
              </div>
            </div>
          </div>

          {/* Project Switcher Dropdown */}
          <div className="relative pl-2 sm:border-l border-slate-800">
            <select
              value={activeProject.id}
              onChange={(e) => onSelectProject(e.target.value)}
              className="bg-[#0e1628] border border-slate-700/80 hover:border-cyan-500/50 rounded-lg px-2.5 py-1 text-xs font-mono text-slate-200 focus:outline-none cursor-pointer max-w-[190px] sm:max-w-[240px] truncate"
            >
              {projects.map((p) => (
                <option key={p.id} value={p.id}>
                  {p.code}: {p.name}
                </option>
              ))}
            </select>
          </div>
        </div>

        {/* Center: Navigation Tabs (Pill style matching screenshot) */}
        <nav className="hidden md:flex items-center gap-1 bg-[#0b1220] p-1 rounded-xl border border-slate-800/80 shadow-inner">
          <button
            onClick={() => onSelectTab('overview')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'overview'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Home className="w-3.5 h-3.5" />
            <span>Overview</span>
          </button>

          <button
            onClick={() => onSelectTab('projects')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'projects'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <FolderKanban className="w-3.5 h-3.5" />
            <span>Projects</span>
          </button>

          <button
            onClick={() => onSelectTab('materials')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'materials'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Layers className="w-3.5 h-3.5" />
            <span>Material Data & BOQ</span>
          </button>

          <button
            onClick={() => onSelectTab('ai_analysis')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'ai_analysis'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <Sparkles className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Analysis</span>
          </button>

          <button
            onClick={() => onSelectTab('progress')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'progress'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <TrendingUp className="w-3.5 h-3.5" />
            <span>Progress Tracker</span>
          </button>

          <button
            onClick={() => onSelectTab('risks')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'risks'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <ShieldAlert className="w-3.5 h-3.5 text-amber-400" />
            <span>Risk Register</span>
          </button>

          <button
            onClick={() => onSelectTab('reports')}
            className={`flex items-center gap-1.5 px-3 py-1.5 rounded-lg text-xs font-medium font-sans transition-all ${
              currentTab === 'reports'
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50 glow-sm-cyan shadow-sm'
                : 'text-slate-400 hover:text-slate-200 hover:bg-slate-800/40'
            }`}
          >
            <FileText className="w-3.5 h-3.5" />
            <span>Reports</span>
          </button>
        </nav>

        {/* Right: Telemetry status, user avatar (as in screenshot) */}
        <div className="flex items-center gap-3">
          {/* Gemini Live AI Status */}
          <div className="flex items-center gap-1.5 px-2.5 py-1 rounded-full bg-slate-900 border border-slate-800 text-[11px] font-mono">
            <span
              className={`w-2 h-2 rounded-full ${
                hasGeminiKey ? 'bg-emerald-400 shadow-sm animate-pulse' : 'bg-cyan-400'
              }`}
            />
            <span className="text-slate-300 hidden lg:inline">
              {hasGeminiKey ? 'Gemini 3.8 Flash Online' : 'AI Inspection Active'}
            </span>
          </div>

          {/* User Profile Avatar with QA Engineer badge */}
          <div className="flex items-center gap-2 pl-2 border-l border-slate-800">
            <div className="w-7 h-7 rounded-full bg-gradient-to-tr from-cyan-600 to-indigo-600 flex items-center justify-center text-xs font-bold text-white shadow ring-1 ring-cyan-500/50">
              CE
            </div>
            <div className="hidden xl:block text-left text-xs font-mono leading-none">
              <div className="text-slate-200 font-semibold">Eng. M. Patel</div>
              <div className="text-[10px] text-cyan-400">Chief QA/QC</div>
            </div>
          </div>
        </div>
      </div>

      {/* Mobile Tab Scrollbar */}
      <div className="md:hidden flex items-center gap-1 overflow-x-auto px-4 py-2 border-t border-slate-800/60 bg-[#070b13] text-xs">
        {(
          [
            ['overview', 'Overview'],
            ['projects', 'Projects'],
            ['materials', 'BOQ Data'],
            ['ai_analysis', 'AI Analysis'],
            ['progress', 'Progress'],
            ['risks', 'Risks'],
            ['reports', 'Reports'],
          ] as const
        ).map(([tabKey, label]) => (
          <button
            key={tabKey}
            onClick={() => onSelectTab(tabKey as NavTab)}
            className={`px-3 py-1 rounded-lg whitespace-nowrap font-mono text-xs ${
              currentTab === tabKey
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/50'
                : 'text-slate-400 hover:text-slate-200'
            }`}
          >
            {label}
          </button>
        ))}
      </div>
    </header>
  );
};
