import React from 'react';
import {
  ShieldAlert,
  Sparkles,
  Layers,
  FileSpreadsheet,
  Cpu,
  ArrowRight,
  CheckCircle2,
  Box,
  Eye,
  ShieldCheck,
  TrendingUp
} from 'lucide-react';

interface ProductLandingModalProps {
  isOpen: boolean;
  onClose: () => void;
  onOpenWorkspace: () => void;
}

export const ProductLandingModal: React.FC<ProductLandingModalProps> = ({
  isOpen,
  onClose,
  onOpenWorkspace,
}) => {
  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 z-50 bg-black/85 backdrop-blur-md flex items-center justify-center p-4 overflow-y-auto">
      <div className="bg-[#0b101c] border border-cyan-800/80 rounded-2xl max-w-4xl w-full p-6 sm:p-8 shadow-2xl text-slate-100 space-y-6 relative animate-in fade-in zoom-in-95 my-8">
        {/* Close Button */}
        <button
          onClick={onClose}
          className="absolute top-5 right-5 text-slate-400 hover:text-white p-2 rounded-lg bg-slate-900 border border-slate-800 text-sm font-mono"
        >
          ✕
        </button>

        {/* Hero Header */}
        <div className="space-y-3">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-cyan-950/80 border border-cyan-700/60 text-cyan-300 text-xs font-mono">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>CIVIL ENGINEERING TECHNOLOGY PLATFORM</span>
          </div>
          <h1 className="text-2xl sm:text-3xl font-extrabold font-mono tracking-tight text-white">
            CiviTwin AI — Construction Site Intelligence & Digital Twin Workspace
          </h1>
          <p className="text-sm text-slate-300 leading-relaxed max-w-2xl">
            A high-precision engineering workspace bridging interactive 3D digital twins, Gemini multimodal vision evidence, deterministic BOQ quantity analytics, and risk registers for civil contractors and project directors.
          </p>
        </div>

        {/* Core Architectural Pillars */}
        <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-cyan-500/10 border border-cyan-500/30 flex items-center justify-center text-cyan-400">
              <Box className="w-4 h-4" />
            </div>
            <h3 className="font-mono font-semibold text-sm text-slate-100">
              Interactive 3D Digital Twin
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Real Three.js isometric building schema with Foundation, Superstructure, Slabs, Masonry, and MEP layer isolation, inspection pins, and confidence heatmaps.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-amber-500/10 border border-amber-500/30 flex items-center justify-center text-amber-400">
              <Eye className="w-4 h-4" />
            </div>
            <h3 className="font-mono font-semibold text-sm text-slate-100">
              Gemini Vision Image Review
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Evaluates site photos for visible works and stockpiled materials. Returns explicit confidence levels and visual uncertainty explanations without fabricating findings.
            </p>
          </div>

          <div className="p-4 rounded-xl bg-slate-900/80 border border-slate-800 space-y-2">
            <div className="w-8 h-8 rounded-lg bg-emerald-500/10 border border-emerald-500/30 flex items-center justify-center text-emerald-400">
              <FileSpreadsheet className="w-4 h-4" />
            </div>
            <h3 className="font-mono font-semibold text-sm text-slate-100">
              Deterministic BOQ Analytics
            </h3>
            <p className="text-xs text-slate-400 leading-relaxed">
              Rigorous CSV import with validation against invalid quantities and inconsistent units. Calculates totals deterministically from quantity × unit rate.
            </p>
          </div>
        </div>

        {/* Operating Boundary & Non-Certification Guarantee */}
        <div className="p-4 rounded-xl bg-amber-950/40 border border-amber-600/50 text-xs text-amber-200 space-y-2">
          <div className="flex items-center gap-2 font-mono font-bold text-amber-300 uppercase">
            <ShieldAlert className="w-4 h-4 text-amber-400" />
            <span>Professional Civil Engineering Boundary</span>
          </div>
          <p className="leading-relaxed text-amber-200/90">
            CiviTwin AI is an advisory planning and digital twin decision-support system. It never claims that a single photo proves the completion of an entire structure, and does not certify concrete compressive strength, rebar tensile strength, soil bearing capacity, or building code compliance. All structural approvals require licensed Professional Engineer (PE / SE) physical evaluation.
          </p>
        </div>

        {/* Action Button */}
        <div className="flex items-center justify-between pt-2 border-t border-slate-800">
          <span className="text-xs font-mono text-slate-500">
            Preloaded with demonstration project data & sample photos
          </span>
          <button
            onClick={() => {
              onClose();
              onOpenWorkspace();
            }}
            className="px-5 py-2.5 rounded-xl bg-cyan-500 text-slate-950 font-bold hover:bg-cyan-400 text-xs font-mono flex items-center gap-2 transition-all glow-cyan"
          >
            <span>Launch Live Workspace</span>
            <ArrowRight className="w-4 h-4" />
          </button>
        </div>
      </div>
    </div>
  );
};
