import React from 'react';
import { Project } from '../types';
import {
  Printer,
  Download,
  FileText,
  ShieldAlert,
  CheckCircle2,
  Calendar,
  Building,
  DollarSign,
  Layers,
  MapPin
} from 'lucide-react';
import Papa from 'papaparse';

interface ProjectReportViewProps {
  project: Project;
}

export const ProjectReportView: React.FC<ProjectReportViewProps> = ({ project }) => {
  const totalBOQValue = project.boqItems.reduce((acc, i) => acc + i.totalCost, 0);
  const actualExpenditure = project.boqItems.reduce((acc, i) => {
    return acc + (i.actualQuantityUsed || 0) * i.unitRate;
  }, 0);
  const avgObservedProgress = Math.round(
    project.phases.reduce((acc, p) => acc + p.observedPercent, 0) / (project.phases.length || 1)
  );

  const handlePrint = () => {
    window.print();
  };

  const handleExportSummaryCSV = () => {
    const reportData = [
      { Section: 'PROJECT METADATA', Field: 'Project Name', Value: project.name },
      { Section: 'PROJECT METADATA', Field: 'Project Code', Value: project.code },
      { Section: 'PROJECT METADATA', Field: 'Location', Value: project.location },
      { Section: 'PROJECT METADATA', Field: 'Start Date', Value: project.startDate },
      { Section: 'PROJECT METADATA', Field: 'Target End Date', Value: project.endDate },
      { Section: 'FINANCIALS', Field: 'Planned Budget ($)', Value: project.plannedBudget },
      { Section: 'FINANCIALS', Field: 'Total BOQ Estimate ($)', Value: totalBOQValue },
      { Section: 'FINANCIALS', Field: 'Expenditure to Date ($)', Value: actualExpenditure },
      { Section: 'PROGRESS', Field: 'Overall Observed Progress (%)', Value: `${avgObservedProgress}%` },
      { Section: 'ISSUES', Field: 'Open Issues Count', Value: project.issues.filter((i) => i.status === 'open').length },
      { Section: 'ISSUES', Field: 'Total Logged Issues', Value: project.issues.length },
    ];

    const csv = Papa.unparse(reportData);
    const blob = new Blob([csv], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${project.code}-Project-Executive-Report.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  return (
    <div className="space-y-4">
      {/* Action Toolbar (hidden when printing) */}
      <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl flex items-center justify-between print:hidden">
        <div>
          <h2 className="text-sm font-bold text-slate-100 font-mono uppercase flex items-center gap-2">
            <FileText className="w-4 h-4 text-cyan-400" />
            <span>Project Executive Intelligence Summary Report</span>
          </h2>
          <p className="text-xs text-slate-400 mt-0.5">
            Printable and exportable project audit summary. Includes progress milestones, financial drawdowns, and issue register.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={handleExportSummaryCSV}
            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-all"
          >
            <Download className="w-3.5 h-3.5" />
            <span>Export Report CSV</span>
          </button>
          <button
            onClick={handlePrint}
            className="px-3.5 py-2 rounded-lg bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 text-xs font-mono flex items-center gap-1.5 transition-all glow-sm-cyan"
          >
            <Printer className="w-3.5 h-3.5" />
            <span>Print Report</span>
          </button>
        </div>
      </div>

      {/* Printable Report Document Card */}
      <div className="bg-[#0a0f1a] border border-slate-800 rounded-xl p-6 sm:p-8 shadow-2xl text-slate-200 space-y-6 print:bg-white print:text-black print:p-0 print:border-none">
        {/* Document Header */}
        <div className="border-b border-slate-800 pb-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-xs font-mono text-cyan-400 mb-1">
              <span>CIVITWIN AI INTELLIGENCE PLATFORM</span>
              <span>•</span>
              <span>EXECUTIVE REPORT</span>
            </div>
            <h1 className="text-xl sm:text-2xl font-bold font-mono tracking-tight text-slate-100">
              {project.name}
            </h1>
            <div className="flex flex-wrap items-center gap-3 text-xs text-slate-400 font-mono mt-1">
              <span>Code: {project.code}</span>
              <span>•</span>
              <span>Location: {project.location}</span>
              <span>•</span>
              <span>Type: {project.projectType}</span>
            </div>
          </div>

          <div className="text-right text-xs font-mono text-slate-400 space-y-1">
            <div>Generated: {new Date().toLocaleDateString()}</div>
            <div>Report Datum: Active Phase ({project.activePhase.toUpperCase()})</div>
            {project.isDemo && (
              <span className="inline-block px-2 py-0.5 rounded bg-amber-950/80 border border-amber-700 text-amber-300 text-[10px]">
                DEMO PROJECT DATA
              </span>
            )}
          </div>
        </div>

        {/* Disclaimer Notice: No Fake Signatures / Certifications */}
        <div className="p-3.5 rounded-lg bg-slate-900 border border-slate-800 text-xs text-slate-300 flex items-start gap-3">
          <ShieldAlert className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-semibold text-amber-300 font-mono text-[11px] uppercase">
              Notice of Engineering Advisory Scope
            </span>
            <p className="text-[11px] text-slate-400 leading-relaxed">
              This summary is a programmatic planning compilation. In strict compliance with professional engineering standards, this system generates no simulated seals, fake professional engineer stamps, or unverified structural compliance certificates. All physical safety certifications must be issued separately by a licensed Professional Engineer.
            </p>
          </div>
        </div>

        {/* Executive Metrics Overview */}
        <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 p-4 rounded-xl bg-slate-900/60 border border-slate-800/80 font-mono">
          <div>
            <div className="text-[10px] text-slate-400 uppercase">Target Budget</div>
            <div className="text-lg font-bold text-slate-100 mt-0.5">
              ${project.plannedBudget.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-cyan-400 uppercase">BOQ Estimate</div>
            <div className="text-lg font-bold text-cyan-300 mt-0.5">
              ${totalBOQValue.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-amber-400 uppercase">Actual Drawn</div>
            <div className="text-lg font-bold text-amber-300 mt-0.5">
              ${actualExpenditure.toLocaleString()}
            </div>
          </div>
          <div>
            <div className="text-[10px] text-slate-400 uppercase">Observed Progress</div>
            <div className="text-lg font-bold text-slate-100 mt-0.5">
              {avgObservedProgress}%
            </div>
          </div>
        </div>

        {/* Phase Progress Table */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase font-mono text-cyan-400">
            1. Construction Phase Milestone Breakdown
          </h3>
          <div className="overflow-x-auto rounded-lg border border-slate-800">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-[10px] text-slate-400 border-b border-slate-800 uppercase">
                <tr>
                  <th className="p-2">Phase</th>
                  <th className="p-2 text-right">Planned (%)</th>
                  <th className="p-2 text-right">Observed (%)</th>
                  <th className="p-2">Dates</th>
                  <th className="p-2">Status</th>
                  <th className="p-2">Engineer Field Note</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {project.phases.map((phase) => (
                  <tr key={phase.id} className="hover:bg-slate-900/40">
                    <td className="p-2 font-semibold text-slate-200">{phase.name}</td>
                    <td className="p-2 text-right text-slate-400">{phase.plannedPercent}%</td>
                    <td className="p-2 text-right text-cyan-300">{phase.observedPercent}%</td>
                    <td className="p-2 text-slate-400 text-[11px]">
                      {phase.startDate} → {phase.targetEndDate}
                    </td>
                    <td className="p-2 capitalize text-slate-300">{phase.status}</td>
                    <td className="p-2 font-sans text-slate-400 text-[11px] truncate max-w-xs">
                      {phase.notes || '—'}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* BOQ Summary by Category */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase font-mono text-cyan-400">
            2. BOQ Cost Allocation by Category
          </h3>
          <div className="overflow-x-auto rounded-lg border border-slate-800">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-[10px] text-slate-400 border-b border-slate-800 uppercase">
                <tr>
                  <th className="p-2">Code</th>
                  <th className="p-2">Category</th>
                  <th className="p-2">Description</th>
                  <th className="p-2 text-right">Quantity</th>
                  <th className="p-2 text-right">Rate</th>
                  <th className="p-2 text-right">Estimated Total</th>
                  <th className="p-2 text-right">Drawn Total</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {project.boqItems.map((item) => {
                  const drawn = (item.actualQuantityUsed || 0) * item.unitRate;
                  return (
                    <tr key={item.id} className="hover:bg-slate-900/40">
                      <td className="p-2 text-cyan-300">{item.itemCode}</td>
                      <td className="p-2 text-slate-400">{item.category}</td>
                      <td className="p-2 font-sans text-slate-200 truncate max-w-xs">
                        {item.description}
                      </td>
                      <td className="p-2 text-right text-slate-300">
                        {item.quantity.toLocaleString()} {item.unit}
                      </td>
                      <td className="p-2 text-right text-slate-300">${item.unitRate.toFixed(2)}</td>
                      <td className="p-2 text-right text-cyan-300 font-semibold">
                        ${item.totalCost.toLocaleString()}
                      </td>
                      <td className="p-2 text-right text-amber-300">${drawn.toLocaleString()}</td>
                    </tr>
                  );
                })}
              </tbody>
            </table>
          </div>
        </div>

        {/* Risk & Issue Register Summary */}
        <div className="space-y-2">
          <h3 className="text-xs font-bold uppercase font-mono text-cyan-400">
            3. Open Risk & Observation Register
          </h3>
          <div className="overflow-x-auto rounded-lg border border-slate-800">
            <table className="w-full text-left text-xs font-mono">
              <thead className="bg-slate-900 text-[10px] text-slate-400 border-b border-slate-800 uppercase">
                <tr>
                  <th className="p-2">Severity</th>
                  <th className="p-2">Issue Title</th>
                  <th className="p-2">Location</th>
                  <th className="p-2">Assigned To</th>
                  <th className="p-2">Due Date</th>
                  <th className="p-2">Status</th>
                  <th className="p-2">PE Sign-off Required</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-800/60">
                {project.issues.map((issue) => (
                  <tr key={issue.id} className="hover:bg-slate-900/40">
                    <td className="p-2">
                      <span
                        className={`text-[9px] uppercase px-1.5 py-0.5 rounded font-bold ${
                          issue.severity === 'high' || issue.severity === 'critical'
                            ? 'bg-red-950 text-red-300'
                            : 'bg-amber-950 text-amber-300'
                        }`}
                      >
                        {issue.severity}
                      </span>
                    </td>
                    <td className="p-2 text-slate-200 font-sans font-medium">{issue.title}</td>
                    <td className="p-2 text-slate-400">{issue.location}</td>
                    <td className="p-2 text-slate-300">{issue.assignedTo}</td>
                    <td className="p-2 text-slate-400">{issue.dueDate}</td>
                    <td className="p-2 capitalize text-slate-300">{issue.status.replace('_', ' ')}</td>
                    <td className="p-2">
                      {issue.requiresPEVerification ? (
                        <span className="text-amber-400">Yes (Mandatory)</span>
                      ) : (
                        <span className="text-slate-500">Standard QA</span>
                      )}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Report Footer */}
        <div className="pt-4 border-t border-slate-800 flex flex-col sm:flex-row items-center justify-between text-[11px] font-mono text-slate-500 gap-2">
          <span>CiviTwin AI — Construction Intelligence & Digital Twin Platform</span>
          <span>Advisory Decision Support System • ISO 19650 Information Container</span>
        </div>
      </div>
    </div>
  );
};
