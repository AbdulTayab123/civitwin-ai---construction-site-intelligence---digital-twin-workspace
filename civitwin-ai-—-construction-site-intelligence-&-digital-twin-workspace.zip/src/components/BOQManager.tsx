import React, { useState } from 'react';
import Papa from 'papaparse';
import { BOQItem, Project } from '../types';
import {
  FileSpreadsheet,
  Upload,
  Download,
  AlertTriangle,
  CheckCircle2,
  DollarSign,
  Edit2,
  Trash2,
  Plus,
  HelpCircle,
  FileCheck,
  Search,
  Filter,
  Calculator
} from 'lucide-react';
import { SAMPLE_CSV_TEMPLATE } from '../data/sampleProject';

interface BOQManagerProps {
  project: Project;
  onUpdateBOQItems: (items: BOQItem[]) => void;
  onUpdatePlannedBudget: (budget: number) => void;
}

interface ValidationIssue {
  rowIndex: number;
  field: string;
  message: string;
}

export const BOQManager: React.FC<BOQManagerProps> = ({
  project,
  onUpdateBOQItems,
  onUpdatePlannedBudget,
}) => {
  const [items, setItems] = useState<BOQItem[]>(project.boqItems);
  const [validationIssues, setValidationIssues] = useState<ValidationIssue[]>([]);
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState<string>('all');
  const [editingItemId, setEditingItemId] = useState<string | null>(null);
  const [editingItemData, setEditingItemData] = useState<Partial<BOQItem>>({});
  const [budgetInput, setBudgetInput] = useState<number>(project.plannedBudget);
  const [isAddingNew, setIsAddingNew] = useState(false);

  // New item draft
  const [newItem, setNewItem] = useState<Partial<BOQItem>>({
    itemCode: '',
    category: 'Concrete & Rebar',
    description: '',
    unit: 'm³',
    quantity: 100,
    unitRate: 150,
  });

  // Calculate totals deterministically
  const totalEstimatedCost = items.reduce((sum, item) => sum + item.totalCost, 0);
  const actualExpenditure = items.reduce((sum, item) => {
    const used = item.actualQuantityUsed ?? 0;
    return sum + used * item.unitRate;
  }, 0);
  const budgetVariance = project.plannedBudget - totalEstimatedCost;

  // Handle CSV Import
  const handleCSVUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    Papa.parse(file, {
      header: true,
      skipEmptyLines: true,
      complete: (results) => {
        const issues: ValidationIssue[] = [];
        const parsedItems: BOQItem[] = [];

        results.data.forEach((row: any, index: number) => {
          const rowNum = index + 1;
          const itemCode = row['Item Code'] || row['ItemCode'] || row['code'] || `BOQ-${rowNum}`;
          const description = row['Description'] || row['Item Name'] || row['description'];
          const unit = row['Unit'] || row['unit'];
          const rawQty = row['Quantity'] || row['quantity'] || row['Qty'];
          const rawRate = row['Unit Rate'] || row['unitRate'] || row['Rate'] || row['price'];
          const category = row['Category'] || row['category'] || 'General';

          if (!description) {
            issues.push({ rowIndex: rowNum, field: 'description', message: 'Missing item description' });
          }
          if (!unit) {
            issues.push({ rowIndex: rowNum, field: 'unit', message: 'Missing unit of measurement' });
          }

          const quantity = parseFloat(rawQty);
          if (isNaN(quantity) || quantity <= 0) {
            issues.push({ rowIndex: rowNum, field: 'quantity', message: `Invalid quantity "${rawQty}"` });
          }

          const unitRate = parseFloat(rawRate);
          if (isNaN(unitRate) || unitRate < 0) {
            issues.push({ rowIndex: rowNum, field: 'unitRate', message: `Invalid unit rate "${rawRate}"` });
          }

          if (description && unit && !isNaN(quantity) && !isNaN(unitRate)) {
            const calculatedTotal = Number((quantity * unitRate).toFixed(2));
            parsedItems.push({
              id: `imported-${Date.now()}-${index}`,
              itemCode,
              category: (category as any) || 'General',
              description,
              unit,
              quantity,
              unitRate,
              totalCost: calculatedTotal,
              actualQuantityUsed: 0,
            });
          }
        });

        setValidationIssues(issues);

        if (parsedItems.length > 0) {
          const updated = [...items, ...parsedItems];
          setItems(updated);
          onUpdateBOQItems(updated);
        }
      },
      error: (err) => {
        setValidationIssues([{ rowIndex: 0, field: 'file', message: `CSV parse error: ${err.message}` }]);
      },
    });
  };

  // Download Current BOQ as CSV
  const handleDownloadCSV = () => {
    const csvData = items.map((i) => ({
      'Item Code': i.itemCode,
      Category: i.category,
      Description: i.description,
      Unit: i.unit,
      Quantity: i.quantity,
      'Unit Rate': i.unitRate,
      'Total Estimated Cost': i.totalCost,
      'Actual Quantity Used': i.actualQuantityUsed || 0,
      'Expenditure to Date': ((i.actualQuantityUsed || 0) * i.unitRate).toFixed(2),
    }));

    const csvString = Papa.unparse(csvData);
    const blob = new Blob([csvString], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', `${project.code}-BOQ-Schedule.csv`);
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Download sample template
  const handleDownloadTemplate = () => {
    const blob = new Blob([SAMPLE_CSV_TEMPLATE], { type: 'text/csv;charset=utf-8;' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.setAttribute('download', 'CiviTwin-BOQ-Import-Template.csv');
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
  };

  // Inline edit handlers
  const startEditItem = (item: BOQItem) => {
    setEditingItemId(item.id);
    setEditingItemData({ ...item });
  };

  const saveEditItem = () => {
    if (!editingItemId) return;
    const qty = Number(editingItemData.quantity) || 0;
    const rate = Number(editingItemData.unitRate) || 0;
    const totalCost = Number((qty * rate).toFixed(2));

    const updated = items.map((item) =>
      item.id === editingItemId
        ? ({ ...item, ...editingItemData, quantity: qty, unitRate: rate, totalCost } as BOQItem)
        : item
    );
    setItems(updated);
    onUpdateBOQItems(updated);
    setEditingItemId(null);
  };

  const deleteItem = (id: string) => {
    const updated = items.filter((item) => item.id !== id);
    setItems(updated);
    onUpdateBOQItems(updated);
  };

  const handleAddNewItem = () => {
    if (!newItem.description || !newItem.itemCode) return;
    const qty = Number(newItem.quantity) || 1;
    const rate = Number(newItem.unitRate) || 0;
    const totalCost = Number((qty * rate).toFixed(2));

    const created: BOQItem = {
      id: `boq-new-${Date.now()}`,
      itemCode: newItem.itemCode || `ITEM-${items.length + 1}`,
      category: (newItem.category as any) || 'General',
      description: newItem.description || '',
      unit: newItem.unit || 'units',
      quantity: qty,
      unitRate: rate,
      totalCost,
      actualQuantityUsed: 0,
    };

    const updated = [...items, created];
    setItems(updated);
    onUpdateBOQItems(updated);
    setIsAddingNew(false);
    setNewItem({
      itemCode: '',
      category: 'Concrete & Rebar',
      description: '',
      unit: 'm³',
      quantity: 100,
      unitRate: 150,
    });
  };

  const categories = ['all', 'Concrete & Rebar', 'Earthwork', 'Masonry', 'MEP Services', 'Finishes', 'General'];

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.itemCode.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'all' || item.category === selectedCategory;
    return matchesSearch && matchesCategory;
  });

  return (
    <div className="space-y-4">
      {/* Rate Disclaimer Notice */}
      <div className="bg-[#0e1627] border border-cyan-800/60 rounded-xl p-3 flex items-start justify-between gap-3 text-xs text-slate-300">
        <div className="flex items-start gap-2.5">
          <Calculator className="w-4 h-4 text-cyan-400 flex-shrink-0 mt-0.5" />
          <div className="space-y-0.5">
            <span className="font-semibold text-cyan-300 font-mono text-[11px] uppercase">
              Deterministic BOQ Quantity & Cost Engine
            </span>
            <p className="text-[11px] text-slate-400">
              Costs are calculated deterministically as <code>Total = Quantity × Unit Rate</code>.
              Sample rates are illustrative and fully editable to reflect local bill rates and contractor quotes.
            </p>
          </div>
        </div>
      </div>

      {/* Financial Overview Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[10px] uppercase font-mono text-slate-400">Target Project Budget</div>
          <div className="text-xl font-bold font-mono text-slate-100 mt-1">
            ${project.plannedBudget.toLocaleString()}
          </div>
          <div className="flex items-center gap-1 mt-1 text-[10px] text-slate-500 font-mono">
            <span>Editable in project settings</span>
          </div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[10px] uppercase font-mono text-cyan-400">Total BOQ Estimate</div>
          <div className="text-xl font-bold font-mono text-cyan-300 mt-1">
            ${totalEstimatedCost.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-400 font-mono mt-1">Sum of {items.length} line items</div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[10px] uppercase font-mono text-slate-400">Expenditure to Date</div>
          <div className="text-xl font-bold font-mono text-amber-300 mt-1">
            ${actualExpenditure.toLocaleString()}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            {((actualExpenditure / (totalEstimatedCost || 1)) * 100).toFixed(1)}% drawn down
          </div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[10px] uppercase font-mono text-slate-400">Budget Variance</div>
          <div
            className={`text-xl font-bold font-mono mt-1 ${
              budgetVariance >= 0 ? 'text-emerald-400' : 'text-red-400'
            }`}
          >
            {budgetVariance >= 0
              ? `+$${budgetVariance.toLocaleString()}`
              : `-$${Math.abs(budgetVariance).toLocaleString()}`}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-1">
            {budgetVariance >= 0 ? 'Under target budget' : 'Estimated cost exceeds target budget'}
          </div>
        </div>
      </div>

      {/* CSV Validation Errors Banner */}
      {validationIssues.length > 0 && (
        <div className="bg-red-950/40 border border-red-700/60 rounded-xl p-3.5 text-xs text-red-200 space-y-1.5">
          <div className="flex items-center gap-2 font-semibold text-red-300 font-mono">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            <span>CSV Validation Flagged {validationIssues.length} Inconsistencies</span>
          </div>
          <div className="space-y-1 max-h-24 overflow-y-auto font-mono text-[11px] pl-6">
            {validationIssues.map((v, i) => (
              <div key={i}>
                Row {v.rowIndex}: {v.message} ({v.field})
              </div>
            ))}
          </div>
        </div>
      )}

      {/* BOQ Toolbar & Actions */}
      <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl space-y-3">
        <div className="flex flex-col md:flex-row md:items-center justify-between gap-3">
          <div className="flex items-center gap-2">
            <FileSpreadsheet className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold font-mono uppercase text-slate-100">
              Bill of Quantities (BOQ) Schedule
            </h3>
            <span className="text-xs font-mono text-cyan-400 px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800">
              {items.length} items
            </span>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Download Template */}
            <button
              onClick={handleDownloadTemplate}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Sample CSV</span>
            </button>

            {/* Export Current BOQ */}
            <button
              onClick={handleDownloadCSV}
              className="px-2.5 py-1.5 rounded-lg bg-cyan-500/15 border border-cyan-500/40 hover:bg-cyan-500/25 text-cyan-300 text-xs font-mono flex items-center gap-1.5 transition-all"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Export CSV</span>
            </button>

            {/* Upload CSV */}
            <label className="px-2.5 py-1.5 rounded-lg bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 text-xs font-mono flex items-center gap-1.5 cursor-pointer transition-all">
              <Upload className="w-3.5 h-3.5" />
              <span>Import CSV</span>
              <input type="file" accept=".csv" onChange={handleCSVUpload} className="hidden" />
            </label>

            {/* Add New Line Item Button */}
            <button
              onClick={() => setIsAddingNew(!isAddingNew)}
              className="px-2.5 py-1.5 rounded-lg bg-slate-800 border border-slate-700 hover:bg-slate-700 text-slate-200 text-xs font-mono flex items-center gap-1.5 transition-all"
            >
              <Plus className="w-3.5 h-3.5" />
              <span>Add Item</span>
            </button>
          </div>
        </div>

        {/* Search & Category Filter Bar */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-2 pt-2 border-t border-slate-800/60">
          <div className="flex items-center gap-1.5 overflow-x-auto w-full sm:w-auto pb-1 sm:pb-0 text-[11px] font-mono">
            {categories.map((cat) => (
              <button
                key={cat}
                onClick={() => setSelectedCategory(cat)}
                className={`px-2.5 py-1 rounded-md transition-all whitespace-nowrap capitalize ${
                  selectedCategory === cat
                    ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40'
                    : 'text-slate-400 hover:text-slate-200'
                }`}
              >
                {cat}
              </button>
            ))}
          </div>

          <div className="relative w-full sm:w-60">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search code or description..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 font-mono"
            />
          </div>
        </div>

        {/* Add Item Drawer */}
        {isAddingNew && (
          <div className="p-3 bg-slate-950 border border-cyan-800/70 rounded-xl space-y-3 text-xs animate-in fade-in">
            <div className="font-semibold text-cyan-300 font-mono text-xs">
              Add New BOQ Line Item
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-6 gap-2">
              <input
                type="text"
                placeholder="Item Code (e.g. CONC-01)"
                value={newItem.itemCode}
                onChange={(e) => setNewItem({ ...newItem, itemCode: e.target.value })}
                className="bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 font-mono text-xs"
              />
              <select
                value={newItem.category}
                onChange={(e) => setNewItem({ ...newItem, category: e.target.value as any })}
                className="bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 font-mono text-xs"
              >
                <option value="Concrete & Rebar">Concrete & Rebar</option>
                <option value="Earthwork">Earthwork</option>
                <option value="Masonry">Masonry</option>
                <option value="MEP Services">MEP Services</option>
                <option value="Finishes">Finishes</option>
                <option value="General">General</option>
              </select>
              <input
                type="text"
                placeholder="Description"
                value={newItem.description}
                onChange={(e) => setNewItem({ ...newItem, description: e.target.value })}
                className="sm:col-span-2 bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 text-xs"
              />
              <input
                type="text"
                placeholder="Unit (m³, tonnes, etc.)"
                value={newItem.unit}
                onChange={(e) => setNewItem({ ...newItem, unit: e.target.value })}
                className="bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 font-mono text-xs"
              />
              <div className="flex gap-2">
                <input
                  type="number"
                  placeholder="Quantity"
                  value={newItem.quantity}
                  onChange={(e) => setNewItem({ ...newItem, quantity: Number(e.target.value) })}
                  className="w-1/2 bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 font-mono text-xs"
                />
                <input
                  type="number"
                  placeholder="Unit Rate"
                  value={newItem.unitRate}
                  onChange={(e) => setNewItem({ ...newItem, unitRate: Number(e.target.value) })}
                  className="w-1/2 bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-200 font-mono text-xs"
                />
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-1">
              <button
                onClick={() => setIsAddingNew(false)}
                className="px-3 py-1 rounded text-slate-400 hover:text-white"
              >
                Cancel
              </button>
              <button
                onClick={handleAddNewItem}
                className="px-3 py-1 rounded bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400"
              >
                Insert Item
              </button>
            </div>
          </div>
        )}

        {/* Tabular Schedule */}
        <div className="overflow-x-auto rounded-lg border border-slate-800">
          <table className="w-full text-left text-xs">
            <thead className="bg-slate-950 text-[10px] font-mono uppercase text-slate-400 border-b border-slate-800">
              <tr>
                <th className="p-2.5">Code</th>
                <th className="p-2.5">Category</th>
                <th className="p-2.5">Description</th>
                <th className="p-2.5 text-right">Unit</th>
                <th className="p-2.5 text-right">Qty</th>
                <th className="p-2.5 text-right">Rate ($)</th>
                <th className="p-2.5 text-right">Total ($)</th>
                <th className="p-2.5 text-right">Used Qty</th>
                <th className="p-2.5 text-center">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-800/60 font-mono">
              {filteredItems.map((item) => {
                const isEditing = editingItemId === item.id;
                return (
                  <tr key={item.id} className="hover:bg-slate-800/30 transition-colors">
                    <td className="p-2.5 text-cyan-300 font-semibold">{item.itemCode}</td>
                    <td className="p-2.5 text-slate-400">{item.category}</td>
                    <td className="p-2.5 font-sans text-slate-200 max-w-xs truncate">
                      {isEditing ? (
                        <input
                          type="text"
                          value={editingItemData.description || ''}
                          onChange={(e) =>
                            setEditingItemData({ ...editingItemData, description: e.target.value })
                          }
                          className="bg-slate-900 border border-cyan-500 rounded p-1 w-full text-xs font-sans text-white"
                        />
                      ) : (
                        item.description
                      )}
                    </td>
                    <td className="p-2.5 text-right text-slate-400">{item.unit}</td>
                    <td className="p-2.5 text-right text-slate-200">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editingItemData.quantity || 0}
                          onChange={(e) =>
                            setEditingItemData({
                              ...editingItemData,
                              quantity: Number(e.target.value),
                            })
                          }
                          className="bg-slate-900 border border-cyan-500 rounded p-1 w-20 text-right text-xs font-mono text-white"
                        />
                      ) : (
                        item.quantity.toLocaleString()
                      )}
                    </td>
                    <td className="p-2.5 text-right text-slate-200">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editingItemData.unitRate || 0}
                          onChange={(e) =>
                            setEditingItemData({
                              ...editingItemData,
                              unitRate: Number(e.target.value),
                            })
                          }
                          className="bg-slate-900 border border-cyan-500 rounded p-1 w-20 text-right text-xs font-mono text-white"
                        />
                      ) : (
                        `$${item.unitRate.toFixed(2)}`
                      )}
                    </td>
                    <td className="p-2.5 text-right text-cyan-300 font-semibold">
                      ${item.totalCost.toLocaleString()}
                    </td>
                    <td className="p-2.5 text-right text-amber-300">
                      {isEditing ? (
                        <input
                          type="number"
                          value={editingItemData.actualQuantityUsed || 0}
                          onChange={(e) =>
                            setEditingItemData({
                              ...editingItemData,
                              actualQuantityUsed: Number(e.target.value),
                            })
                          }
                          className="bg-slate-900 border border-cyan-500 rounded p-1 w-16 text-right text-xs font-mono text-white"
                        />
                      ) : (
                        item.actualQuantityUsed ?? 0
                      )}
                    </td>
                    <td className="p-2.5 text-center">
                      <div className="flex items-center justify-center gap-1">
                        {isEditing ? (
                          <button
                            onClick={saveEditItem}
                            className="px-2 py-0.5 rounded bg-cyan-500 text-slate-950 font-semibold text-[11px]"
                          >
                            Save
                          </button>
                        ) : (
                          <button
                            onClick={() => startEditItem(item)}
                            className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400"
                          >
                            <Edit2 className="w-3.5 h-3.5" />
                          </button>
                        )}
                        <button
                          onClick={() => deleteItem(item.id)}
                          className="p-1 rounded hover:bg-slate-800 text-slate-400 hover:text-red-400"
                        >
                          <Trash2 className="w-3.5 h-3.5" />
                        </button>
                      </div>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      </div>
    </div>
  );
};
