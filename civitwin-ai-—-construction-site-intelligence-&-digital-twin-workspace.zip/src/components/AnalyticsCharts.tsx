import React from 'react';
import { Project } from '../types';
import { TrendingUp, BarChart3, PieChart, Activity, ShieldCheck, CheckCircle2 } from 'lucide-react';

interface AnalyticsChartsProps {
  project: Project;
}

export const AnalyticsCharts: React.FC<AnalyticsChartsProps> = ({ project }) => {
  // Compute deterministic aggregations
  const totalBOQValue = project.boqItems.reduce((acc, item) => acc + item.totalCost, 0);
  const actualExpenditure = project.boqItems.reduce((acc, item) => {
    const used = item.actualQuantityUsed ?? 0;
    return acc + used * item.unitRate;
  }, 0);

  // Group by Category for Doughnut chart
  const categorySums: { [key: string]: number } = {};
  project.boqItems.forEach((item) => {
    categorySums[item.category] = (categorySums[item.category] || 0) + item.totalCost;
  });

  const categories = Object.keys(categorySums);
  const categoryColors: { [key: string]: string } = {
    'Concrete & Rebar': '#00e5ff',
    'Earthwork': '#3b82f6',
    'Masonry': '#f59e0b',
    'MEP Services': '#10b981',
    'Finishes': '#a855f7',
    'General': '#64748b',
    'Structural Steel': '#ec4899',
  };

  // Bar Chart Data: top materials by volume or cost
  const barItems = project.boqItems.slice(0, 5).map((item) => {
    const usage = item.actualQuantityUsed ? Math.round((item.actualQuantityUsed / item.quantity) * 100) : 0;
    return {
      label: item.itemCode.substring(0, 8),
      fullName: item.itemCode,
      value: usage,
    };
  });

  // Calculate overall planned vs observed progress weighted across phases
  const avgPlanned = Math.round(
    project.phases.reduce((acc, p) => acc + p.plannedPercent, 0) / (project.phases.length || 1)
  );
  const avgObserved = Math.round(
    project.phases.reduce((acc, p) => acc + p.observedPercent, 0) / (project.phases.length || 1)
  );

  return (
    <div className="flex flex-col gap-3.5 h-full">
      {/* 1. Bar Chart Card (as in screenshot) */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3.5 shadow-xl flex flex-col">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase font-mono text-slate-200">
            <BarChart3 className="w-3.5 h-3.5 text-cyan-400" />
            <span>Material Consumption (% of BOQ)</span>
          </div>
          <span className="text-[10px] font-mono text-cyan-400">Live Sync</span>
        </div>

        {/* SVG Bar Chart */}
        <div className="h-28 w-full flex items-end justify-between gap-2 pt-2 px-1 border-b border-slate-800/60 pb-1">
          {barItems.map((bar, i) => (
            <div key={i} className="flex-1 flex flex-col items-center h-full justify-end group">
              <div className="text-[9px] font-mono text-cyan-300 opacity-0 group-hover:opacity-100 transition-opacity mb-0.5">
                {bar.value}%
              </div>
              <div className="w-full max-w-[28px] bg-slate-800/80 rounded-t-sm overflow-hidden h-20 flex items-end">
                <div
                  className="w-full rounded-t-sm transition-all duration-700 bg-gradient-to-t from-cyan-600 to-cyan-400 group-hover:brightness-125"
                  style={{ height: `${Math.max(8, bar.value)}%` }}
                />
              </div>
              <span className="text-[9px] font-mono text-slate-400 truncate w-full text-center mt-1">
                {bar.label}
              </span>
            </div>
          ))}
        </div>
      </div>

      {/* 2. Line Graph Card (Planned vs Actual Progress trajectory) */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3.5 shadow-xl flex flex-col">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase font-mono text-slate-200">
            <TrendingUp className="w-3.5 h-3.5 text-cyan-400" />
            <span>Progress Curve (S-Curve)</span>
          </div>
          <div className="flex items-center gap-2 text-[10px] font-mono">
            <span className="flex items-center gap-1 text-slate-400">
              <span className="w-2 h-0.5 bg-slate-500"></span> Planned
            </span>
            <span className="flex items-center gap-1 text-cyan-400">
              <span className="w-2 h-0.5 bg-cyan-400"></span> Observed
            </span>
          </div>
        </div>

        {/* Crisp Line Graph SVG */}
        <div className="h-24 w-full relative pt-1">
          <svg className="w-full h-full overflow-visible" viewBox="0 0 240 80">
            <defs>
              <linearGradient id="lineGrad" x1="0" y1="0" x2="0" y2="1">
                <stop offset="0%" stopColor="#06b6d4" stopOpacity="0.35" />
                <stop offset="100%" stopColor="#06b6d4" stopOpacity="0.0" />
              </linearGradient>
            </defs>
            {/* Grid lines */}
            <line x1="0" y1="20" x2="240" y2="20" stroke="#1e293b" strokeDasharray="3 3" />
            <line x1="0" y1="50" x2="240" y2="50" stroke="#1e293b" strokeDasharray="3 3" />

            {/* Planned line (dashed gray) */}
            <polyline
              fill="none"
              stroke="#64748b"
              strokeWidth="2"
              strokeDasharray="4 3"
              points="0,75 48,60 96,40 144,25 192,15 240,8"
            />

            {/* Area under observed curve */}
            <polygon
              fill="url(#lineGrad)"
              points="0,75 48,65 96,46 144,35 170,33 170,80 0,80"
            />

            {/* Observed line (cyan with points) */}
            <polyline
              fill="none"
              stroke="#00e5ff"
              strokeWidth="2.5"
              points="0,75 48,65 96,46 144,35 170,33"
            />

            {/* Current point indicator */}
            <circle cx="170" cy="33" r="3.5" fill="#00e5ff" stroke="#080e18" strokeWidth="2" />
          </svg>
        </div>

        <div className="flex justify-between text-[9px] font-mono text-slate-500 mt-1 px-1">
          <span>Aug '25</span>
          <span>Nov '25</span>
          <span>Feb '26</span>
          <span>May '26</span>
          <span>Dec '26</span>
        </div>
      </div>

      {/* 3. Doughnut Chart Card (Category Budget Allocations) */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3.5 shadow-xl flex flex-col flex-1">
        <div className="flex items-center justify-between mb-2">
          <div className="flex items-center gap-1.5 text-xs font-semibold uppercase font-mono text-slate-200">
            <PieChart className="w-3.5 h-3.5 text-cyan-400" />
            <span>Budget Allocation Breakdown</span>
          </div>
          <span className="text-[10px] font-mono text-slate-400">
            ${(totalBOQValue / 1000).toFixed(0)}k
          </span>
        </div>

        <div className="flex items-center gap-3 py-1 flex-1">
          {/* SVG Doughnut */}
          <div className="w-24 h-24 relative flex-shrink-0 flex items-center justify-center">
            <svg className="w-full h-full -rotate-90" viewBox="0 0 36 36">
              {/* Background ring */}
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#1e293b"
                strokeWidth="4.5"
              />
              {/* Segment 1: Concrete */}
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#00e5ff"
                strokeWidth="4.5"
                strokeDasharray="45, 100"
              />
              {/* Segment 2: Steel */}
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#f59e0b"
                strokeWidth="4.5"
                strokeDasharray="25, 100"
                strokeDashoffset="-45"
              />
              {/* Segment 3: Earthwork & MEP */}
              <path
                d="M18 2.0845 a 15.9155 15.9155 0 0 1 0 31.831 a 15.9155 15.9155 0 0 1 0 -31.831"
                fill="none"
                stroke="#10b981"
                strokeWidth="4.5"
                strokeDasharray="20, 100"
                strokeDashoffset="-70"
              />
            </svg>
            <div className="absolute flex flex-col items-center">
              <span className="text-[10px] font-mono text-cyan-300 font-bold">{avgObserved}%</span>
              <span className="text-[8px] text-slate-500 font-mono">OBSVD</span>
            </div>
          </div>

          {/* Legend Items */}
          <div className="flex-1 space-y-1.5 overflow-hidden text-[11px] font-mono">
            {categories.slice(0, 4).map((cat) => {
              const amount = categorySums[cat];
              const pct = Math.round((amount / (totalBOQValue || 1)) * 100);
              const color = categoryColors[cat] || '#94a3b8';
              return (
                <div key={cat} className="flex items-center justify-between">
                  <div className="flex items-center gap-1.5 truncate">
                    <span
                      className="w-2 h-2 rounded-full flex-shrink-0"
                      style={{ backgroundColor: color }}
                    />
                    <span className="text-slate-300 truncate text-[10px]">{cat}</span>
                  </div>
                  <span className="text-slate-400 text-[10px] font-mono">{pct}%</span>
                </div>
              );
            })}
          </div>
        </div>
      </div>
    </div>
  );
};

export const BottomTelemetryStatus: React.FC<{ project: Project }> = ({ project }) => {
  const avgObserved = Math.round(
    project.phases.reduce((acc, p) => acc + p.observedPercent, 0) / (project.phases.length || 1)
  );

  const openIssues = project.issues.filter((i) => i.status === 'open' || i.status === 'under_review').length;

  return (
    <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
      {/* 1. AI Analysis Status (matching screenshot) */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3 flex items-center justify-between shadow-lg">
        <div className="space-y-1">
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5 uppercase">
            <Activity className="w-3.5 h-3.5 text-cyan-400" />
            <span>AI Visual Inspection Status</span>
          </div>
          <div className="text-lg font-mono font-bold text-slate-100 flex items-baseline gap-2">
            <span>Score: 92/100</span>
            <span className="text-[10px] text-emerald-400 font-normal">Sufficient Clarity</span>
          </div>
          <div className="flex items-center gap-1 text-[10px] text-slate-500 font-mono">
            <span>Evidence records: {project.siteFindings.length + 3} frames</span>
          </div>
        </div>
        <div className="flex gap-1">
          <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 shadow-sm animate-pulse"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-cyan-400"></span>
          <span className="w-2.5 h-2.5 rounded-full bg-amber-400"></span>
        </div>
      </div>

      {/* 2. Project Progress (matching screenshot) */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3 flex items-center justify-between shadow-lg">
        <div className="space-y-1 w-full mr-3">
          <div className="text-[11px] font-mono text-slate-400 flex items-center justify-between uppercase">
            <span>Observed Completion</span>
            <span className="text-cyan-400 font-bold">{avgObserved}%</span>
          </div>
          <div className="w-full bg-slate-800 h-2 rounded-full overflow-hidden">
            <div
              className="bg-gradient-to-r from-cyan-500 to-cyan-300 h-full rounded-full transition-all duration-700"
              style={{ width: `${avgObserved}%` }}
            />
          </div>
          <div className="flex justify-between text-[10px] text-slate-500 font-mono">
            <span>Phase: {project.activePhase.toUpperCase()}</span>
            <span>Planned: 68%</span>
          </div>
        </div>
      </div>

      {/* 3. Risk & Engineering Governance Check */}
      <div className="bg-[#0d131f] border border-slate-800/90 rounded-xl p-3 flex items-center justify-between shadow-lg">
        <div className="space-y-1">
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-1.5 uppercase">
            <ShieldCheck className="w-3.5 h-3.5 text-amber-400" />
            <span>Open Issues & Compliance</span>
          </div>
          <div className="text-lg font-mono font-bold text-slate-100 flex items-baseline gap-2">
            <span>{openIssues} Pending Actions</span>
            {openIssues > 0 ? (
              <span className="text-[10px] text-amber-400 font-normal">PE Review Required</span>
            ) : (
              <span className="text-[10px] text-emerald-400 font-normal">All Cleared</span>
            )}
          </div>
          <div className="text-[10px] text-slate-500 font-mono truncate">
            Decision-support tool (Non-certifying)
          </div>
        </div>
        <div className="p-2 rounded-lg bg-slate-900 border border-slate-800">
          <CheckCircle2 className="w-5 h-5 text-cyan-400" />
        </div>
      </div>
    </div>
  );
};
