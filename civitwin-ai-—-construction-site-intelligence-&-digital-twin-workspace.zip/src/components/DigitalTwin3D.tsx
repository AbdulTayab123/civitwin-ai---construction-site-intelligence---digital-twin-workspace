import React, { useEffect, useRef, useState } from 'react';
import * as THREE from 'three';
import { DigitalTwinLayerConfig, DigitalTwinRenderMode } from '../types';
import {
  Layers,
  Eye,
  RotateCcw,
  ZoomIn,
  ZoomOut,
  Maximize2,
  Info,
  ShieldCheck,
  Cpu,
  Box,
  MapPin,
  ChevronDown
} from 'lucide-react';

interface DigitalTwin3DProps {
  activePhase?: string;
  onSelectElement?: (elementInfo: any) => void;
  openIssuesCount?: number;
}

export const DigitalTwin3D: React.FC<DigitalTwin3DProps> = ({
  activePhase = 'structure',
  onSelectElement,
  openIssuesCount = 3
}) => {
  const mountRef = useRef<HTMLDivElement>(null);
  const [renderMode, setRenderMode] = useState<DigitalTwinRenderMode>('wireframe');
  const [layers, setLayers] = useState<DigitalTwinLayerConfig>({
    foundation: true,
    superstructure: true,
    slabs: true,
    masonry: true,
    mep: false,
    finishes: false,
  });
  const [selectedElement, setSelectedElement] = useState<any>(null);
  const [showLayerMenu, setShowLayerMenu] = useState(false);
  const [showHotspots, setShowHotspots] = useState(true);
  const [isFullscreen, setIsFullscreen] = useState(false);

  // References to three objects
  const sceneRef = useRef<THREE.Scene | null>(null);
  const cameraRef = useRef<THREE.PerspectiveCamera | null>(null);
  const rendererRef = useRef<THREE.WebGLRenderer | null>(null);
  const groupsRef = useRef<{ [key: string]: THREE.Group }>({});
  const raycasterRef = useRef<THREE.Raycaster>(new THREE.Raycaster());
  const mouseRef = useRef<THREE.Vector2>(new THREE.Vector2());

  // Interactive camera orbit state
  const isDraggingRef = useRef(false);
  const prevMousePos = useRef({ x: 0, y: 0 });
  const cameraAngle = useRef({ theta: Math.PI / 4, phi: Math.PI / 3, radius: 36 });
  const cameraTarget = useRef(new THREE.Vector3(0, 4, 0));

  const updateCameraPosition = () => {
    if (!cameraRef.current) return;
    const { theta, phi, radius } = cameraAngle.current;
    cameraRef.current.position.x = cameraTarget.current.x + radius * Math.sin(phi) * Math.sin(theta);
    cameraRef.current.position.y = cameraTarget.current.y + radius * Math.cos(phi);
    cameraRef.current.position.z = cameraTarget.current.z + radius * Math.sin(phi) * Math.cos(theta);
    cameraRef.current.lookAt(cameraTarget.current);
  };

  useEffect(() => {
    const container = mountRef.current;
    if (!container) return;

    // Scene
    const scene = new THREE.Scene();
    sceneRef.current = scene;
    scene.background = new THREE.Color(0x080e18);

    // Fog for depth
    scene.fog = new THREE.FogExp2(0x080e18, 0.015);

    // Camera
    const camera = new THREE.PerspectiveCamera(
      45,
      container.clientWidth / container.clientHeight,
      0.1,
      1000
    );
    cameraRef.current = camera;
    updateCameraPosition();

    // Renderer
    const renderer = new THREE.WebGLRenderer({ antialias: true, alpha: true });
    renderer.setSize(container.clientWidth, container.clientHeight);
    renderer.setPixelRatio(Math.min(window.devicePixelRatio, 2));
    renderer.shadowMap.enabled = true;
    rendererRef.current = renderer;
    container.innerHTML = '';
    container.appendChild(renderer.domElement);

    // Ambient & Directional Lights
    const ambientLight = new THREE.AmbientLight(0x38bdf8, 0.6);
    scene.add(ambientLight);

    const dirLight1 = new THREE.DirectionalLight(0x00f0ff, 1.2);
    dirLight1.position.set(20, 40, 20);
    scene.add(dirLight1);

    const dirLight2 = new THREE.DirectionalLight(0xf59e0b, 0.5);
    dirLight2.position.set(-20, 20, -20);
    scene.add(dirLight2);

    // Blueprint Grid Floor
    const gridHelper = new THREE.GridHelper(50, 50, 0x0ea5e9, 0x1e293b);
    gridHelper.position.y = -0.01;
    scene.add(gridHelper);

    // Layer Groups
    const groupFoundation = new THREE.Group();
    const groupSuperstructure = new THREE.Group();
    const groupSlabs = new THREE.Group();
    const groupMasonry = new THREE.Group();
    const groupMEP = new THREE.Group();
    const groupFinishes = new THREE.Group();
    const groupHotspots = new THREE.Group();

    groupsRef.current = {
      foundation: groupFoundation,
      superstructure: groupSuperstructure,
      slabs: groupSlabs,
      masonry: groupMasonry,
      mep: groupMEP,
      finishes: groupFinishes,
      hotspots: groupHotspots,
    };

    scene.add(groupFoundation);
    scene.add(groupSuperstructure);
    scene.add(groupSlabs);
    scene.add(groupMasonry);
    scene.add(groupMEP);
    scene.add(groupFinishes);
    scene.add(groupHotspots);

    // Build Architectural Geometry
    buildBuildingModel(groupsRef.current);

    // Animation loop
    let reqId: number;
    let clock = new THREE.Clock();

    const animate = () => {
      reqId = requestAnimationFrame(animate);
      const elapsedTime = clock.getElapsedTime();

      // Gentle floating animation for inspection hotspot pins
      groupHotspots.children.forEach((child, idx) => {
        child.position.y += Math.sin(elapsedTime * 2 + idx) * 0.003;
      });

      renderer.render(scene, camera);
    };
    animate();

    // Resize handler
    const handleResize = () => {
      if (!container || !camera || !renderer) return;
      camera.aspect = container.clientWidth / container.clientHeight;
      camera.updateProjectionMatrix();
      renderer.setSize(container.clientWidth, container.clientHeight);
    };

    window.addEventListener('resize', handleResize);

    return () => {
      cancelAnimationFrame(reqId);
      window.removeEventListener('resize', handleResize);
      renderer.dispose();
      if (container && renderer.domElement) {
        container.removeChild(renderer.domElement);
      }
    };
  }, []);

  // Update layer visibilities and render modes
  useEffect(() => {
    Object.keys(layers).forEach((key) => {
      const group = groupsRef.current[key];
      if (group) {
        group.visible = layers[key as keyof DigitalTwinLayerConfig];
      }
    });

    if (groupsRef.current.hotspots) {
      groupsRef.current.hotspots.visible = showHotspots;
    }

    // Update materials according to renderMode
    updateMaterialsRenderMode(renderMode);
  }, [layers, renderMode, showHotspots]);

  // Construct building meshes with structural metadata
  const buildBuildingModel = (groups: { [key: string]: THREE.Group }) => {
    // Shared materials generator
    const wireframeCyan = new THREE.LineBasicMaterial({ color: 0x00e5ff, transparent: true, opacity: 0.85 });
    const wireframeAmber = new THREE.LineBasicMaterial({ color: 0xf59e0b, transparent: true, opacity: 0.8 });
    const wireframeGreen = new THREE.LineBasicMaterial({ color: 0x10b981, transparent: true, opacity: 0.8 });

    // 1. Foundation: Raft slab + Column Pedestals
    const raftGeo = new THREE.BoxGeometry(22, 1.2, 18);
    const raftEdges = new THREE.EdgesGeometry(raftGeo);
    const raftLine = new THREE.LineSegments(raftEdges, wireframeGreen);
    raftLine.position.set(0, 0.6, 0);
    raftLine.userData = {
      name: 'Raft Foundation Slab',
      layer: 'foundation',
      volume: '475 m³',
      material: 'C35/45 Waterproof Concrete',
      qaStatus: 'Verified 100%',
      confidence: 96,
      boqCode: 'CONC-C35-FND'
    };
    groups.foundation.add(raftLine);

    // Footing grade beams
    for (let x = -8; x <= 8; x += 8) {
      for (let z = -6; z <= 6; z += 6) {
        const pedGeo = new THREE.BoxGeometry(2.2, 1.5, 2.2);
        const pedEdges = new THREE.EdgesGeometry(pedGeo);
        const pedLine = new THREE.LineSegments(pedEdges, wireframeCyan);
        pedLine.position.set(x, 1.35, z);
        pedLine.userData = {
          name: `Column Base Pedestal [${x},${z}]`,
          layer: 'foundation',
          volume: '7.2 m³',
          material: 'Reinforced Concrete',
          qaStatus: 'Verified 100%',
          confidence: 94,
        };
        groups.foundation.add(pedLine);
      }
    }

    // 2. Superstructure: 4 Levels of Columns + Lift Core + Beams
    const levels = 4;
    const storyHeight = 3.2;

    // Central Lift Core / Shear Wall
    const coreHeight = levels * storyHeight;
    const coreGeo = new THREE.BoxGeometry(5, coreHeight, 5);
    const coreEdges = new THREE.EdgesGeometry(coreGeo);
    const coreLine = new THREE.LineSegments(coreEdges, wireframeAmber);
    coreLine.position.set(0, coreHeight / 2 + 1.2, 0);
    coreLine.userData = {
      name: 'Central Shear Wall & Lift Core',
      layer: 'superstructure',
      volume: '168 m³',
      material: 'Reinforced Concrete C40',
      qaStatus: 'Level 3 Underway',
      confidence: 88,
      boqCode: 'CORE-RCC-40'
    };
    groups.superstructure.add(coreLine);

    // Columns grid (3 x 3 grid minus center core)
    const colCoords = [
      [-8, -6], [0, -6], [8, -6],
      [-8, 0],           [8, 0],
      [-8, 6],  [0, 6],  [8, 6],
    ];

    colCoords.forEach(([x, z], idx) => {
      for (let l = 0; l < levels; l++) {
        const colGeo = new THREE.BoxGeometry(0.8, storyHeight, 0.8);
        const colEdges = new THREE.EdgesGeometry(colGeo);
        const colLine = new THREE.LineSegments(colEdges, wireframeCyan);
        colLine.position.set(x, 1.2 + l * storyHeight + storyHeight / 2, z);
        colLine.userData = {
          name: `RCC Column C-${idx + 1} (L${l + 1})`,
          layer: 'superstructure',
          volume: '2.05 m³',
          material: 'High-Strength Concrete + Fe500D Rebar',
          qaStatus: l <= 2 ? 'Approved' : 'Tying Rebar',
          confidence: l <= 2 ? 95 : 82,
        };
        groups.superstructure.add(colLine);
      }
    });

    // Perimeter and tie beams on each level
    for (let l = 1; l <= levels; l++) {
      const beamY = 1.2 + l * storyHeight;
      // Perimeter frame beams
      const beamGeoX1 = new THREE.BoxGeometry(18, 0.6, 0.6);
      const beamEdgesX1 = new THREE.EdgesGeometry(beamGeoX1);
      const bX1 = new THREE.LineSegments(beamEdgesX1, wireframeCyan);
      bX1.position.set(0, beamY, -6);
      groups.superstructure.add(bX1);

      const bX2 = new THREE.LineSegments(beamEdgesX1, wireframeCyan);
      bX2.position.set(0, beamY, 6);
      groups.superstructure.add(bX2);

      const beamGeoZ1 = new THREE.BoxGeometry(0.6, 0.6, 12);
      const beamEdgesZ1 = new THREE.EdgesGeometry(beamGeoZ1);
      const bZ1 = new THREE.LineSegments(beamEdgesZ1, wireframeCyan);
      bZ1.position.set(-8, beamY, 0);
      groups.superstructure.add(bZ1);

      const bZ2 = new THREE.LineSegments(beamEdgesZ1, wireframeCyan);
      bZ2.position.set(8, beamY, 0);
      groups.superstructure.add(bZ2);
    }

    // 3. Slabs: Suspended floor plates
    for (let l = 1; l <= levels; l++) {
      const slabGeo = new THREE.BoxGeometry(20, 0.35, 16);
      const slabEdges = new THREE.EdgesGeometry(slabGeo);
      const slabLine = new THREE.LineSegments(slabEdges, wireframeCyan);
      slabLine.position.set(0, 1.2 + l * storyHeight, 0);
      slabLine.userData = {
        name: `Level ${l} Suspended Floor Slab`,
        layer: 'slabs',
        volume: '112 m³',
        material: 'C35 Post-Tensioned Concrete',
        qaStatus: l <= 3 ? 'Poured & Cured' : 'Formwork Ready',
        confidence: l <= 3 ? 98 : 79,
      };
      groups.slabs.add(slabLine);
    }

    // 4. Masonry: Exterior wall panels and internal partitions
    for (let l = 1; l <= 2; l++) {
      const wallY = 1.2 + (l - 1) * storyHeight + storyHeight / 2;
      // North & South wall wireframes
      const wallGeo = new THREE.BoxGeometry(7, storyHeight - 0.4, 0.3);
      const wallEdges = new THREE.EdgesGeometry(wallGeo);
      
      const wallN1 = new THREE.LineSegments(wallEdges, wireframeCyan);
      wallN1.position.set(-4.5, wallY, -5.8);
      wallN1.userData = {
        name: `Level ${l} North AAC Masonry Wall`,
        layer: 'masonry',
        volume: '14.5 m²',
        material: '200mm AAC Blockwork',
        qaStatus: 'In Progress',
        confidence: 86,
      };
      groups.masonry.add(wallN1);

      const wallN2 = new THREE.LineSegments(wallEdges, wireframeCyan);
      wallN2.position.set(4.5, wallY, -5.8);
      wallN2.userData = {
        name: `Level ${l} North-East Enclosure`,
        layer: 'masonry',
        volume: '14.5 m²',
        material: '200mm AAC Blockwork',
        qaStatus: 'In Progress',
        confidence: 84,
      };
      groups.masonry.add(wallN2);
    }

    // 5. MEP Services: High-visibility ducting and pipe runs
    const ductGeo1 = new THREE.BoxGeometry(16, 0.4, 0.8);
    const ductEdges1 = new THREE.EdgesGeometry(ductGeo1);
    const ductLine1 = new THREE.LineSegments(ductEdges1, wireframeAmber);
    ductLine1.position.set(0, 1.2 + 1 * storyHeight - 0.4, 2);
    ductLine1.userData = {
      name: 'Level 1 Primary Supply Air Duct (Galvanized GI)',
      layer: 'mep',
      volume: '38 m²',
      material: 'Sheet Metal + 25mm Fiberglass Insulation',
      qaStatus: 'Fabricated',
      confidence: 76,
    };
    groups.mep.add(ductLine1);

    // 6. Inspection Hotspot Pins
    const pinData = [
      { pos: new THREE.Vector3(-4, 7.8, 3), title: 'Rebar Cover Inspection Bay 2', severity: 'medium', id: 'issue-01' },
      { pos: new THREE.Vector3(0, 1.8, -6), title: 'North Shoring Seepage Observation', severity: 'high', id: 'issue-02' },
      { pos: new THREE.Vector3(8, 11, -3), title: 'Level 4 Perimeter Edge Guardrail', severity: 'high', id: 'issue-03' }
    ];

    pinData.forEach((pin) => {
      const pinSphereGeo = new THREE.SphereGeometry(0.35, 12, 12);
      const pinMat = new THREE.MeshBasicMaterial({
        color: pin.severity === 'high' ? 0xef4444 : 0xf59e0b,
      });
      const pinMesh = new THREE.Mesh(pinSphereGeo, pinMat);
      pinMesh.position.copy(pin.pos);

      // Add a small pulsating wireframe ring around it
      const ringGeo = new THREE.RingGeometry(0.5, 0.7, 16);
      const ringMat = new THREE.MeshBasicMaterial({
        color: pin.severity === 'high' ? 0xef4444 : 0x06b6d4,
        side: THREE.DoubleSide,
        transparent: true,
        opacity: 0.7,
      });
      const ringMesh = new THREE.Mesh(ringGeo, ringMat);
      ringMesh.rotation.x = Math.PI / 2;
      pinMesh.add(ringMesh);

      pinMesh.userData = {
        name: pin.title,
        isHotspot: true,
        severity: pin.severity,
        id: pin.id
      };
      groups.hotspots.add(pinMesh);
    });
  };

  const updateMaterialsRenderMode = (mode: DigitalTwinRenderMode) => {
    // Mode toggling logic across scene lines and meshes
    Object.values(groupsRef.current).forEach((group) => {
      group.traverse((child: any) => {
        if (child.isLineSegments) {
          if (mode === 'heatmap') {
            const conf = child.userData?.confidence || 75;
            let heatColor = 0x10b981; // green
            if (conf < 80) heatColor = 0xf59e0b; // amber
            if (conf < 65) heatColor = 0xef4444; // red
            child.material.color.setHex(heatColor);
            child.material.opacity = 0.95;
          } else if (mode === 'solid') {
            child.material.color.setHex(0x38bdf8);
            child.material.opacity = 0.6;
          } else {
            // standard wireframe cyan
            const defaultColor = child.userData?.layer === 'foundation' ? 0x10b981 : 0x00e5ff;
            child.material.color.setHex(defaultColor);
            child.material.opacity = 0.85;
          }
        }
      });
    });
  };

  // Mouse interaction handlers for 3D navigation and raycasting
  const handleMouseDown = (e: React.MouseEvent) => {
    isDraggingRef.current = true;
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (!isDraggingRef.current) return;
    const deltaX = e.clientX - prevMousePos.current.x;
    const deltaY = e.clientY - prevMousePos.current.y;

    cameraAngle.current.theta -= deltaX * 0.007;
    cameraAngle.current.phi = Math.max(0.1, Math.min(Math.PI / 2 - 0.05, cameraAngle.current.phi - deltaY * 0.007));

    updateCameraPosition();
    prevMousePos.current = { x: e.clientX, y: e.clientY };
  };

  const handleMouseUp = () => {
    isDraggingRef.current = false;
  };

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    cameraAngle.current.radius = Math.max(12, Math.min(65, cameraAngle.current.radius + e.deltaY * 0.02));
    updateCameraPosition();
  };

  const handleCanvasClick = (e: React.MouseEvent) => {
    const container = mountRef.current;
    if (!container || !cameraRef.current || !sceneRef.current) return;

    const rect = container.getBoundingClientRect();
    mouseRef.current.x = ((e.clientX - rect.left) / container.clientWidth) * 2 - 1;
    mouseRef.current.y = -((e.clientY - rect.top) / container.clientHeight) * 2 + 1;

    raycasterRef.current.setFromCamera(mouseRef.current, cameraRef.current);
    const intersects = raycasterRef.current.intersectObjects(sceneRef.current.children, true);

    const hit = intersects.find((item) => item.object.userData && item.object.userData.name);
    if (hit) {
      setSelectedElement(hit.object.userData);
      if (onSelectElement) onSelectElement(hit.object.userData);
    }
  };

  const zoomIn = () => {
    cameraAngle.current.radius = Math.max(12, cameraAngle.current.radius - 5);
    updateCameraPosition();
  };

  const zoomOut = () => {
    cameraAngle.current.radius = Math.min(65, cameraAngle.current.radius + 5);
    updateCameraPosition();
  };

  const resetView = () => {
    cameraAngle.current = { theta: Math.PI / 4, phi: Math.PI / 3, radius: 36 };
    cameraTarget.current.set(0, 4, 0);
    updateCameraPosition();
  };

  return (
    <div className="relative w-full h-full bg-[#080e18] rounded-xl overflow-hidden border border-slate-800 shadow-2xl flex flex-col">
      {/* Top Overlay Controls Bar (as in user screenshot) */}
      <div className="absolute top-3 left-3 right-3 z-20 flex items-center justify-between pointer-events-none">
        {/* Left: Search & Model Status */}
        <div className="flex items-center gap-2 pointer-events-auto">
          <div className="flex items-center gap-2 px-3 py-1.5 rounded-lg bg-[#0e1726]/90 border border-cyan-900/60 backdrop-blur-md text-xs font-mono text-cyan-300 shadow-lg">
            <span className="w-2 h-2 rounded-full bg-cyan-400 animate-pulse"></span>
            <span>BIM-TWIN: LVL 1-4 ACTIVE</span>
          </div>

          <div className="hidden sm:flex items-center gap-1 px-2.5 py-1.5 rounded-lg bg-[#0e1726]/90 border border-slate-700/60 backdrop-blur-md text-xs text-slate-300">
            <Cpu className="w-3.5 h-3.5 text-amber-400" />
            <span className="font-mono text-[11px]">PHASE: {activePhase.toUpperCase()}</span>
          </div>
        </div>

        {/* Right: Layers, Mode Toggle, Hotspots */}
        <div className="flex items-center gap-2 pointer-events-auto">
          {/* Layer Selector Dropdown */}
          <div className="relative">
            <button
              onClick={() => setShowLayerMenu(!showLayerMenu)}
              className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-[#0e1726]/90 border border-slate-700/80 hover:border-cyan-500/50 backdrop-blur-md text-xs text-slate-200 transition-all shadow-md"
            >
              <Layers className="w-3.5 h-3.5 text-cyan-400" />
              <span>Layers</span>
              <ChevronDown className="w-3 h-3 text-slate-400" />
            </button>

            {showLayerMenu && (
              <div className="absolute right-0 mt-2 w-48 bg-[#0c1322] border border-slate-700/80 rounded-xl p-2.5 shadow-2xl z-30 text-xs backdrop-blur-xl">
                <div className="text-[10px] font-mono uppercase text-slate-400 px-2 py-1 border-b border-slate-800 mb-1">
                  Structural Layers
                </div>
                {(Object.keys(layers) as Array<keyof DigitalTwinLayerConfig>).map((layerKey) => (
                  <label
                    key={layerKey}
                    className="flex items-center justify-between px-2 py-1.5 rounded hover:bg-slate-800/60 cursor-pointer text-slate-300 capitalize"
                  >
                    <span>{layerKey}</span>
                    <input
                      type="checkbox"
                      checked={layers[layerKey]}
                      onChange={(e) =>
                        setLayers((prev) => ({ ...prev, [layerKey]: e.target.checked }))
                      }
                      className="rounded border-slate-700 text-cyan-500 focus:ring-0 bg-slate-900"
                    />
                  </label>
                ))}
              </div>
            )}
          </div>

          {/* AI Confidence / Render Mode Toggle (like the AI Mode pill in screenshot) */}
          <div className="flex rounded-lg bg-[#0e1726]/90 border border-slate-700/80 p-0.5 backdrop-blur-md shadow-md text-xs">
            <button
              onClick={() => setRenderMode('wireframe')}
              className={`px-2.5 py-1 rounded-md transition-all font-mono text-[11px] ${
                renderMode === 'wireframe'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/40 glow-sm-cyan'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              CAD Wire
            </button>
            <button
              onClick={() => setRenderMode('heatmap')}
              className={`px-2.5 py-1 rounded-md transition-all font-mono text-[11px] ${
                renderMode === 'heatmap'
                  ? 'bg-amber-500/20 text-amber-300 border border-amber-500/40 glow-amber'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              AI Confidence
            </button>
          </div>

          {/* Toggle Hotspots */}
          <button
            onClick={() => setShowHotspots(!showHotspots)}
            title="Toggle Inspection Issue Hotspots"
            className={`p-1.5 rounded-lg border backdrop-blur-md transition-all ${
              showHotspots
                ? 'bg-amber-500/20 border-amber-500/50 text-amber-300'
                : 'bg-[#0e1726]/90 border-slate-700/80 text-slate-400'
            }`}
          >
            <MapPin className="w-3.5 h-3.5" />
          </button>
        </div>
      </div>

      {/* Left Navigation Buttons (Zoom, Rotate, Pan - as in user screenshot) */}
      <div className="absolute left-3 top-16 z-20 flex flex-col gap-1.5 pointer-events-auto">
        <button
          onClick={zoomIn}
          title="Zoom In"
          className="p-2 rounded-lg bg-[#0e1726]/85 border border-slate-700/70 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-300 transition-all shadow-md backdrop-blur-md"
        >
          <ZoomIn className="w-4 h-4" />
        </button>
        <button
          onClick={zoomOut}
          title="Zoom Out"
          className="p-2 rounded-lg bg-[#0e1726]/85 border border-slate-700/70 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-300 transition-all shadow-md backdrop-blur-md"
        >
          <ZoomOut className="w-4 h-4" />
        </button>
        <button
          onClick={resetView}
          title="Reset Isometric Perspective"
          className="p-2 rounded-lg bg-[#0e1726]/85 border border-slate-700/70 hover:border-cyan-500/60 text-slate-300 hover:text-cyan-300 transition-all shadow-md backdrop-blur-md"
        >
          <RotateCcw className="w-4 h-4" />
        </button>
      </div>

      {/* 3D Canvas Mounting Area */}
      <div
        ref={mountRef}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onWheel={handleWheel}
        onClick={handleCanvasClick}
        className="w-full flex-1 cursor-grab active:cursor-grabbing select-none"
      />

      {/* Floating Blueprint Dimension & Coordinates Overlay */}
      <div className="absolute bottom-3 left-3 z-10 pointer-events-none flex items-center gap-3 text-[11px] font-mono text-cyan-400/80 bg-[#080e18]/80 px-3 py-1.5 rounded-lg border border-cyan-950 backdrop-blur-sm">
        <span>GRID: 8.0m x 6.0m</span>
        <span className="text-slate-600">|</span>
        <span>ROT: ISO-45°</span>
        <span className="text-slate-600">|</span>
        <span>LEVELS: 4/4</span>
      </div>

      {/* Bottom Floating Material Tags (styled like user screenshot) */}
      <div className="absolute bottom-3 right-3 z-10 flex items-center gap-2 pointer-events-auto">
        <div className="px-2.5 py-1 rounded bg-[#0b1220]/90 border border-cyan-800/70 text-[11px] font-mono text-cyan-300 shadow">
          Concrete C35
        </div>
        <div className="px-2.5 py-1 rounded bg-[#0b1220]/90 border border-amber-800/70 text-[11px] font-mono text-amber-300 shadow">
          Rebar Fe500D
        </div>
        <div className="px-2.5 py-1 rounded bg-[#0b1220]/90 border border-emerald-800/70 text-[11px] font-mono text-emerald-300 shadow">
          AAC 200mm
        </div>
      </div>

      {/* Selected Element Inspection Drawer */}
      {selectedElement && (
        <div className="absolute top-16 right-3 w-72 bg-[#0d1526]/95 border border-cyan-500/40 rounded-xl p-3.5 shadow-2xl z-30 text-xs backdrop-blur-xl animate-in fade-in slide-in-from-top-2">
          <div className="flex items-center justify-between pb-2 mb-2 border-b border-slate-800">
            <div className="flex items-center gap-1.5 font-semibold text-cyan-300">
              <Box className="w-4 h-4 text-cyan-400" />
              <span>{selectedElement.name}</span>
            </div>
            <button
              onClick={() => setSelectedElement(null)}
              className="text-slate-400 hover:text-white p-1"
            >
              ×
            </button>
          </div>

          <div className="space-y-1.5 text-slate-300 font-mono text-[11px]">
            {selectedElement.layer && (
              <div className="flex justify-between">
                <span className="text-slate-500">BIM Layer:</span>
                <span className="text-cyan-400 capitalize">{selectedElement.layer}</span>
              </div>
            )}
            {selectedElement.material && (
              <div className="flex justify-between">
                <span className="text-slate-500">Material:</span>
                <span>{selectedElement.material}</span>
              </div>
            )}
            {selectedElement.volume && (
              <div className="flex justify-between">
                <span className="text-slate-500">Quantity / Vol:</span>
                <span>{selectedElement.volume}</span>
              </div>
            )}
            {selectedElement.qaStatus && (
              <div className="flex justify-between">
                <span className="text-slate-500">QA Inspection:</span>
                <span className="text-emerald-400">{selectedElement.qaStatus}</span>
              </div>
            )}
            {selectedElement.confidence && (
              <div className="flex justify-between">
                <span className="text-slate-500">AI Confidence:</span>
                <span className="text-amber-300">{selectedElement.confidence}%</span>
              </div>
            )}
          </div>

          <div className="mt-3 pt-2 border-t border-slate-800/80 flex items-center gap-1 text-[10px] text-slate-400">
            <ShieldCheck className="w-3 h-3 text-cyan-400" />
            <span>Digital twin component calibrated to design drawings</span>
          </div>
        </div>
      )}
    </div>
  );
};
