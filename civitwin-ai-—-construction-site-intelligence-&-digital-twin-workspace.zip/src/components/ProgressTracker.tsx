import React, { useState } from 'react';
import {
  PhaseProgress,
  Project,
  ConstructionPhaseId
} from '../types';
import {
  Calendar,
  Clock,
  CheckCircle2,
  AlertTriangle,
  Edit3,
  Save,
  ShieldCheck,
  Cpu,
  UserCheck,
  TrendingUp,
  Layers
} from 'lucide-react';

interface ProgressTrackerProps {
  project: Project;
  onUpdatePhase: (phaseId: ConstructionPhaseId, updatedData: Partial<PhaseProgress>) => void;
}

export const ProgressTracker: React.FC<ProgressTrackerProps> = ({
  project,
  onUpdatePhase,
}) => {
  const [editingPhaseId, setEditingPhaseId] = useState<ConstructionPhaseId | null>(null);
  const [editObserved, setEditObserved] = useState<number>(0);
  const [editPlanned, setEditPlanned] = useState<number>(0);
  const [editNotes, setEditNotes] = useState<string>('');

  const startEdit = (phase: PhaseProgress) => {
    setEditingPhaseId(phase.id);
    setEditObserved(phase.observedPercent);
    setEditPlanned(phase.plannedPercent);
    setEditNotes(phase.notes || '');
  };

  const saveEdit = (phaseId: ConstructionPhaseId) => {
    onUpdatePhase(phaseId, {
      observedPercent: Math.min(100, Math.max(0, Number(editObserved))),
      plannedPercent: Math.min(100, Math.max(0, Number(editPlanned))),
      notes: editNotes,
      lastUpdated: new Date().toISOString().split('T')[0],
      verifiedByEngineer: true,
    });
    setEditingPhaseId(null);
  };

  // Deterministic summary calculation
  const totalObserved = Math.round(
    project.phases.reduce((sum, p) => sum + p.observedPercent, 0) / (project.phases.length || 1)
  );
  const totalPlanned = Math.round(
    project.phases.reduce((sum, p) => sum + p.plannedPercent, 0) / (project.phases.length || 1)
  );
  const overallVariance = totalObserved - totalPlanned;

  // Determine schedule delay based on target vs current dates
  const calculateDelayDays = (phase: PhaseProgress) => {
    const target = new Date(phase.targetEndDate).getTime();
    const reference = phase.actualEndDate ? new Date(phase.actualEndDate).getTime() : Date.now();
    const diffDays = Math.round((reference - target) / (1000 * 60 * 60 * 24));
    return diffDays;
  };

  return (
    <div className="space-y-4">
      {/* Overview Metric Banner */}
      <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase">Average Planned Target</div>
          <div className="text-2xl font-bold font-mono text-slate-100 mt-1">{totalPlanned}%</div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Baseline schedule</div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[11px] font-mono text-cyan-400 uppercase">Observed Physical Completion</div>
          <div className="text-2xl font-bold font-mono text-cyan-300 mt-1">{totalObserved}%</div>
          <div className="text-[10px] text-slate-400 font-mono mt-0.5">Human engineer verified</div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase">Schedule Variance</div>
          <div className={`text-2xl font-bold font-mono mt-1 ${overallVariance >= 0 ? 'text-emerald-400' : 'text-amber-400'}`}>
            {overallVariance >= 0 ? `+${overallVariance}%` : `${overallVariance}%`}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">
            {overallVariance >= 0 ? 'Ahead of baseline' : 'Variance requiring catchup'}
          </div>
        </div>

        <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-3.5 shadow-lg">
          <div className="text-[11px] font-mono text-slate-400 uppercase">Active Phase</div>
          <div className="text-xl font-bold font-mono text-amber-300 mt-1 capitalize truncate">
            {project.activePhase}
          </div>
          <div className="text-[10px] text-slate-500 font-mono mt-0.5">Under live monitoring</div>
        </div>
      </div>

      {/* Phase Timeline & Cards */}
      <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl space-y-4">
        <div className="flex items-center justify-between pb-3 border-b border-slate-800">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-cyan-400" />
            <h3 className="text-sm font-semibold font-mono uppercase text-slate-100">
              Phase Progress Registry & Milestone Timeline
            </h3>
          </div>
          <div className="text-[11px] font-mono text-slate-400 flex items-center gap-3">
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-slate-600"></span> Planned Baseline
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-cyan-400"></span> Observed (Human)
            </span>
            <span className="flex items-center gap-1.5">
              <span className="w-2.5 h-2.5 rounded bg-amber-400"></span> AI Photo Hint
            </span>
          </div>
        </div>

        {/* Phase List */}
        <div className="space-y-3">
          {project.phases.map((phase, idx) => {
            const isEditing = editingPhaseId === phase.id;
            const delayDays = calculateDelayDays(phase);
            const hasScheduleInfo = Boolean(phase.startDate && phase.targetEndDate);

            return (
              <div
                key={phase.id}
                className={`p-3.5 rounded-xl border transition-all ${
                  project.activePhase === phase.id
                    ? 'bg-[#101828] border-cyan-500/40 glow-sm-cyan'
                    : 'bg-slate-900/60 border-slate-800'
                }`}
              >
                <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 mb-2">
                  <div className="flex items-center gap-2.5">
                    <span className="text-xs font-mono px-2 py-0.5 rounded bg-slate-800 text-slate-400">
                      Phase 0{idx + 1}
                    </span>
                    <h4 className="text-sm font-semibold text-slate-200">{phase.name}</h4>
                    {phase.status === 'completed' && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-emerald-950 border border-emerald-800 text-emerald-400 flex items-center gap-1">
                        <CheckCircle2 className="w-3 h-3" /> Completed
                      </span>
                    )}
                    {project.activePhase === phase.id && (
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-cyan-950 border border-cyan-800 text-cyan-400 animate-pulse">
                        Current Workface
                      </span>
                    )}
                  </div>

                  <div className="flex items-center gap-2 text-xs font-mono">
                    <div className="flex items-center gap-1 text-slate-400 text-[11px]">
                      <Calendar className="w-3 h-3 text-slate-500" />
                      <span>
                        {phase.startDate} → {phase.targetEndDate}
                      </span>
                    </div>

                    {hasScheduleInfo && delayDays > 0 && phase.status !== 'completed' && (
                      <span className="text-[10px] text-amber-400 bg-amber-950/60 px-2 py-0.5 rounded border border-amber-800/80">
                        +{delayDays}d schedule slip
                      </span>
                    )}

                    {!isEditing ? (
                      <button
                        onClick={() => startEdit(phase)}
                        className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors ml-2"
                        title="Edit Phase Progress"
                      >
                        <Edit3 className="w-3.5 h-3.5" />
                      </button>
                    ) : (
                      <button
                        onClick={() => saveEdit(phase.id)}
                        className="px-2.5 py-1 rounded bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 transition-colors text-xs flex items-center gap-1"
                      >
                        <Save className="w-3 h-3" /> Save
                      </button>
                    )}
                  </div>
                </div>

                {/* Progress Bars comparison */}
                <div className="space-y-2 my-3">
                  {/* Planned vs Observed Bar */}
                  <div className="space-y-1">
                    <div className="flex justify-between text-xs font-mono">
                      <span className="text-slate-400 text-[11px]">Planned Baseline: {phase.plannedPercent}%</span>
                      <span className="text-cyan-400 font-semibold text-[11px]">
                        Observed Physical: {phase.observedPercent}%
                      </span>
                    </div>

                    <div className="relative w-full h-3 bg-slate-950 rounded-full overflow-hidden border border-slate-800">
                      {/* Planned marker bar (gray) */}
                      <div
                        className="absolute top-0 bottom-0 left-0 bg-slate-700/60"
                        style={{ width: `${phase.plannedPercent}%` }}
                      />
                      {/* Observed progress bar (cyan) */}
                      <div
                        className="absolute top-0 bottom-0 left-0 bg-gradient-to-r from-cyan-500 to-cyan-300 transition-all duration-500"
                        style={{ width: `${phase.observedPercent}%` }}
                      />
                      {/* AI visual hint marker (amber tick) if present */}
                      {phase.aiObservedHint !== undefined && (
                        <div
                          className="absolute top-0 bottom-0 w-1 bg-amber-400 z-10 shadow"
                          title={`AI Photo Observation Hint: ~${phase.aiObservedHint}%`}
                          style={{ left: `${phase.aiObservedHint}%` }}
                        />
                      )}
                    </div>
                  </div>
                </div>

                {/* Edit Form Drawer */}
                {isEditing && (
                  <div className="mt-3 p-3 rounded-lg bg-slate-950 border border-cyan-800/60 space-y-3 text-xs">
                    <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
                      <div>
                        <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                          Observed Progress (% Physical Completion)
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={editObserved}
                          onChange={(e) => setEditObserved(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 font-mono text-xs focus:border-cyan-400"
                        />
                      </div>
                      <div>
                        <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                          Planned Schedule Baseline (%)
                        </label>
                        <input
                          type="number"
                          min="0"
                          max="100"
                          value={editPlanned}
                          onChange={(e) => setEditPlanned(Number(e.target.value))}
                          className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 font-mono text-xs focus:border-cyan-400"
                        />
                      </div>
                    </div>

                    <div>
                      <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                        Engineer Field Verification Notes
                      </label>
                      <input
                        type="text"
                        value={editNotes}
                        onChange={(e) => setEditNotes(e.target.value)}
                        placeholder="e.g. Level 4 concrete pour completed; rebar tie-in for Level 5 ongoing."
                        className="w-full bg-slate-900 border border-slate-700 rounded p-1.5 text-slate-100 text-xs focus:border-cyan-400"
                      />
                    </div>
                  </div>
                )}

                {/* Verification Metadata Footnote */}
                <div className="flex flex-wrap items-center justify-between text-[11px] font-mono text-slate-400 pt-1 border-t border-slate-800/40">
                  <div className="flex items-center gap-2">
                    <UserCheck className="w-3.5 h-3.5 text-emerald-400" />
                    <span>
                      Manual Field Entry: {phase.observedPercent}% (Verified by Site Engineer)
                    </span>
                  </div>

                  {phase.aiObservedHint !== undefined && (
                    <div className="flex items-center gap-1.5 text-amber-300/80">
                      <Cpu className="w-3 h-3 text-amber-400" />
                      <span>Separate AI Photo Hint: ~{phase.aiObservedHint}%</span>
                    </div>
                  )}

                  <span className="text-slate-500 text-[10px]">Updated: {phase.lastUpdated}</span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
