import React, { useState } from 'react';
import {
  Box,
  Layers,
  CheckCircle2,
  AlertCircle,
  HelpCircle,
  Search,
  Filter,
  SlidersHorizontal,
  FileSpreadsheet
} from 'lucide-react';
import { BOQItem } from '../types';

interface MaterialQuantityTableProps {
  items: BOQItem[];
  onSelectItem?: (item: BOQItem) => void;
  onOpenBOQTab?: () => void;
}

export const MaterialQuantityTable: React.FC<MaterialQuantityTableProps> = ({
  items,
  onSelectItem,
  onOpenBOQTab,
}) => {
  const [filterTab, setFilterTab] = useState<'all' | 'high_usage' | 'ai_verified'>('all');
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedIds, setSelectedIds] = useState<string[]>(['boq-001']);

  const toggleSelect = (id: string) => {
    setSelectedIds((prev) =>
      prev.includes(id) ? prev.filter((item) => item !== id) : [...prev, id]
    );
  };

  const getMaterialIcon = (category: string) => {
    switch (category) {
      case 'Concrete & Rebar':
        return <Box className="w-4 h-4 text-cyan-400" />;
      case 'Masonry':
        return <Layers className="w-4 h-4 text-amber-400" />;
      case 'MEP Services':
        return <SlidersHorizontal className="w-4 h-4 text-emerald-400" />;
      default:
        return <Box className="w-4 h-4 text-slate-400" />;
    }
  };

  const filteredItems = items.filter((item) => {
    const matchesSearch =
      item.description.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.itemCode.toLowerCase().includes(searchQuery.toLowerCase()) ||
      item.category.toLowerCase().includes(searchQuery.toLowerCase());

    if (!matchesSearch) return false;

    if (filterTab === 'high_usage') {
      const usagePercent = item.actualQuantityUsed
        ? (item.actualQuantityUsed / item.quantity) * 100
        : 0;
      return usagePercent > 50;
    }
    if (filterTab === 'ai_verified') {
      return item.actualQuantityUsed !== undefined && item.actualQuantityUsed > 0;
    }
    return true;
  });

  return (
    <div className="flex flex-col h-full bg-[#0d131f] border border-slate-800/90 rounded-xl overflow-hidden shadow-xl">
      {/* Table Header & Controls (matching screenshot) */}
      <div className="p-3.5 border-b border-slate-800/80 bg-[#0e1627]/60">
        <div className="flex items-center justify-between mb-3">
          <div className="flex items-center gap-2">
            <h3 className="text-sm font-semibold tracking-wide text-slate-100 uppercase font-mono">
              Material Quantity
            </h3>
            <span className="text-xs px-2 py-0.5 rounded-full bg-cyan-950/70 border border-cyan-800/50 text-cyan-400 font-mono">
              {items.length} items
            </span>
          </div>

          {onOpenBOQTab && (
            <button
              onClick={onOpenBOQTab}
              className="text-xs text-cyan-400 hover:text-cyan-300 flex items-center gap-1 font-mono transition-colors"
            >
              <FileSpreadsheet className="w-3.5 h-3.5" />
              <span>Full BOQ</span>
            </button>
          )}
        </div>

        {/* Filter Tabs (matching pill buttons in screenshot: Material quantity, Usage, AI Confidence) */}
        <div className="flex items-center justify-between gap-2">
          <div className="flex p-0.5 rounded-lg bg-slate-900/80 border border-slate-800 text-[11px] font-mono">
            <button
              onClick={() => setFilterTab('all')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filterTab === 'all'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Material quantity
            </button>
            <button
              onClick={() => setFilterTab('high_usage')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filterTab === 'high_usage'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Usage &gt;50%
            </button>
            <button
              onClick={() => setFilterTab('ai_verified')}
              className={`px-2.5 py-1 rounded-md transition-all ${
                filterTab === 'ai_verified'
                  ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-500/30'
                  : 'text-slate-400 hover:text-slate-200'
              }`}
            >
              Observed
            </button>
          </div>

          <div className="relative w-36 sm:w-44">
            <Search className="w-3.5 h-3.5 text-slate-500 absolute left-2.5 top-2" />
            <input
              type="text"
              placeholder="Search..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-slate-900/90 border border-slate-800 rounded-lg pl-8 pr-2.5 py-1 text-xs text-slate-200 placeholder-slate-500 focus:outline-none focus:border-cyan-500/60 font-mono"
            />
          </div>
        </div>
      </div>

      {/* Column Headers */}
      <div className="grid grid-cols-12 px-3.5 py-2 text-[10px] font-mono uppercase tracking-wider text-slate-400 border-b border-slate-800/80 bg-slate-950/40">
        <div className="col-span-5 flex items-center gap-2">
          <span>Material</span>
        </div>
        <div className="col-span-4 text-right">
          <span>Planned / Used</span>
        </div>
        <div className="col-span-1 text-center">
          <span>Status</span>
        </div>
        <div className="col-span-2 text-right">
          <span>AI Conf</span>
        </div>
      </div>

      {/* Material List rows */}
      <div className="flex-1 overflow-y-auto divide-y divide-slate-800/40 text-xs">
        {filteredItems.map((item, index) => {
          const isSelected = selectedIds.includes(item.id);
          const used = item.actualQuantityUsed ?? 0;
          const usagePercent = Math.min(100, Math.round((used / item.quantity) * 100));
          // Approximate realistic AI inspection confidence score
          const confidence = 85 + ((index * 3) % 13);

          return (
            <div
              key={item.id}
              onClick={() => {
                toggleSelect(item.id);
                if (onSelectItem) onSelectItem(item);
              }}
              className={`grid grid-cols-12 px-3.5 py-2.5 items-center cursor-pointer transition-colors ${
                isSelected
                  ? 'bg-cyan-950/30 border-l-2 border-l-cyan-400'
                  : 'hover:bg-slate-800/30'
              }`}
            >
              {/* Material Name & Checkbox */}
              <div className="col-span-5 flex items-center gap-2.5 overflow-hidden">
                <input
                  type="checkbox"
                  checked={isSelected}
                  onChange={() => toggleSelect(item.id)}
                  onClick={(e) => e.stopPropagation()}
                  className="rounded border-slate-700 text-cyan-500 focus:ring-0 bg-slate-900/80 cursor-pointer"
                />
                <div className="p-1 rounded bg-slate-800/60 border border-slate-700/50 flex-shrink-0">
                  {getMaterialIcon(item.category)}
                </div>
                <div className="truncate">
                  <div className="text-slate-200 font-medium truncate font-sans text-xs">
                    {item.itemCode}
                  </div>
                  <div className="text-[10px] text-slate-400 truncate font-mono">
                    {item.category}
                  </div>
                </div>
              </div>

              {/* Progress & Values */}
              <div className="col-span-4 px-2 text-right">
                <div className="text-[11px] font-mono text-slate-200 font-semibold">
                  {item.quantity.toLocaleString()}{' '}
                  <span className="text-[10px] text-slate-400 font-normal">{item.unit}</span>
                </div>
                <div className="flex items-center gap-1.5 justify-end mt-1">
                  <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                    <div
                      className={`h-full rounded-full transition-all duration-500 ${
                        usagePercent > 80
                          ? 'bg-amber-400'
                          : usagePercent > 40
                          ? 'bg-cyan-400'
                          : 'bg-slate-600'
                      }`}
                      style={{ width: `${usagePercent}%` }}
                    />
                  </div>
                  <span className="text-[10px] font-mono text-slate-400">
                    {usagePercent}%
                  </span>
                </div>
              </div>

              {/* Status Badge */}
              <div className="col-span-1 flex justify-center">
                {usagePercent >= 100 ? (
                  <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" />
                ) : usagePercent > 0 ? (
                  <span className="w-2 h-2 rounded-full bg-cyan-400"></span>
                ) : (
                  <span className="w-2 h-2 rounded-full bg-slate-600"></span>
                )}
              </div>

              {/* AI Confidence badge (matching circular/pill score in screenshot) */}
              <div className="col-span-2 text-right">
                <span className="inline-flex items-center justify-center px-1.5 py-0.5 rounded-full text-[10px] font-mono font-medium bg-cyan-950/80 border border-cyan-800/60 text-cyan-300">
                  {confidence}
                </span>
              </div>
            </div>
          );
        })}

        {filteredItems.length === 0 && (
          <div className="p-8 text-center text-slate-500 text-xs">
            No materials matching search criteria
          </div>
        )}
      </div>

      {/* Footer Calculation Note */}
      <div className="p-2.5 bg-slate-950/60 border-t border-slate-800/80 flex items-center justify-between text-[11px] font-mono text-slate-400">
        <span>Deterministic BOQ calculations</span>
        <span className="text-cyan-400">Illustrative demo rates</span>
      </div>
    </div>
  );
};
