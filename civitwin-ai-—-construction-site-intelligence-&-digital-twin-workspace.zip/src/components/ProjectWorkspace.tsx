import React, { useState } from 'react';
import { Project, ProjectStatus } from '../types';
import {
  FolderKanban,
  Plus,
  Edit2,
  Trash2,
  Calendar,
  MapPin,
  DollarSign,
  CheckCircle2,
  AlertTriangle,
  Building2,
  Layers,
  ArrowRight,
  ShieldCheck,
  RotateCcw
} from 'lucide-react';

interface ProjectWorkspaceProps {
  projects: Project[];
  activeProjectId: string;
  onSelectProject: (projectId: string) => void;
  onCreateProject: (project: Project) => void;
  onUpdateProject: (projectId: string, updated: Partial<Project>) => void;
  onDeleteProject: (projectId: string) => void;
  onResetDemoProject: () => void;
}

export const ProjectWorkspace: React.FC<ProjectWorkspaceProps> = ({
  projects,
  activeProjectId,
  onSelectProject,
  onCreateProject,
  onUpdateProject,
  onDeleteProject,
  onResetDemoProject,
}) => {
  const [isModalOpen, setIsModalOpen] = useState(false);
  const [editingProject, setEditingProject] = useState<Project | null>(null);

  const [formState, setFormState] = useState({
    name: '',
    code: '',
    location: '',
    projectType: 'Commercial',
    startDate: new Date().toISOString().split('T')[0],
    endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
    plannedBudget: 2500000,
    status: 'planning' as ProjectStatus,
  });

  const openCreateModal = () => {
    setEditingProject(null);
    setFormState({
      name: '',
      code: `CIVI-${Math.floor(100 + Math.random() * 900)}`,
      location: '',
      projectType: 'Commercial',
      startDate: new Date().toISOString().split('T')[0],
      endDate: new Date(Date.now() + 365 * 24 * 60 * 60 * 1000).toISOString().split('T')[0],
      plannedBudget: 2500000,
      status: 'planning',
    });
    setIsModalOpen(true);
  };

  const openEditModal = (proj: Project) => {
    setEditingProject(proj);
    setFormState({
      name: proj.name,
      code: proj.code,
      location: proj.location,
      projectType: proj.projectType,
      startDate: proj.startDate,
      endDate: proj.endDate,
      plannedBudget: proj.plannedBudget,
      status: proj.status,
    });
    setIsModalOpen(true);
  };

  const handleSave = () => {
    if (!formState.name || !formState.location) return;

    if (editingProject) {
      onUpdateProject(editingProject.id, {
        name: formState.name,
        code: formState.code,
        location: formState.location,
        projectType: formState.projectType as any,
        startDate: formState.startDate,
        endDate: formState.endDate,
        plannedBudget: Number(formState.plannedBudget),
        status: formState.status,
        updatedAt: new Date().toISOString(),
      });
    } else {
      const newProj: Project = {
        id: `proj-${Date.now()}`,
        name: formState.name,
        code: formState.code || `CIVI-${Math.floor(100 + Math.random() * 900)}`,
        location: formState.location,
        projectType: formState.projectType as any,
        startDate: formState.startDate,
        endDate: formState.endDate,
        plannedBudget: Number(formState.plannedBudget),
        currency: 'USD',
        status: formState.status,
        isDemo: false,
        activePhase: 'foundation',
        phases: [
          {
            id: 'foundation',
            name: 'Foundation & Substructure',
            plannedPercent: 10,
            observedPercent: 0,
            startDate: formState.startDate,
            targetEndDate: formState.endDate,
            status: 'active',
            lastUpdated: new Date().toISOString().split('T')[0],
            verifiedByEngineer: false,
          },
          {
            id: 'structure',
            name: 'Superstructure Framing',
            plannedPercent: 0,
            observedPercent: 0,
            startDate: formState.startDate,
            targetEndDate: formState.endDate,
            status: 'pending',
            lastUpdated: new Date().toISOString().split('T')[0],
            verifiedByEngineer: false,
          },
          {
            id: 'masonry',
            name: 'Masonry & Enclosure',
            plannedPercent: 0,
            observedPercent: 0,
            startDate: formState.startDate,
            targetEndDate: formState.endDate,
            status: 'pending',
            lastUpdated: new Date().toISOString().split('T')[0],
            verifiedByEngineer: false,
          },
          {
            id: 'services',
            name: 'MEP Services',
            plannedPercent: 0,
            observedPercent: 0,
            startDate: formState.startDate,
            targetEndDate: formState.endDate,
            status: 'pending',
            lastUpdated: new Date().toISOString().split('T')[0],
            verifiedByEngineer: false,
          },
          {
            id: 'finishing',
            name: 'Finishes & Handover',
            plannedPercent: 0,
            observedPercent: 0,
            startDate: formState.startDate,
            targetEndDate: formState.endDate,
            status: 'pending',
            lastUpdated: new Date().toISOString().split('T')[0],
            verifiedByEngineer: false,
          },
        ],
        boqItems: [],
        issues: [],
        siteFindings: [],
        createdAt: new Date().toISOString(),
        updatedAt: new Date().toISOString(),
      };
      onCreateProject(newProj);
    }

    setIsModalOpen(false);
  };

  return (
    <div className="space-y-4">
      {/* Workspace Banner */}
      <div className="bg-[#0d131f] border border-slate-800 rounded-xl p-4 shadow-xl flex flex-col sm:flex-row sm:items-center justify-between gap-3">
        <div>
          <div className="flex items-center gap-2">
            <FolderKanban className="w-5 h-5 text-cyan-400" />
            <h2 className="text-base font-bold text-slate-100 font-mono">
              Civil Engineering Projects Workspace
            </h2>
          </div>
          <p className="text-xs text-slate-400 mt-1">
            Manage digital twins, progress metrics, budgets, and registered site photos. Persisted in local workspace storage.
          </p>
        </div>

        <div className="flex items-center gap-2">
          <button
            onClick={onResetDemoProject}
            className="px-3 py-2 rounded-lg bg-slate-800 hover:bg-slate-700 text-slate-300 text-xs font-mono flex items-center gap-1.5 transition-all"
            title="Reset demonstration project data"
          >
            <RotateCcw className="w-3.5 h-3.5" />
            <span>Reset Demo Project</span>
          </button>

          <button
            onClick={openCreateModal}
            className="px-3.5 py-2 rounded-lg bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 text-xs font-mono flex items-center gap-1.5 transition-all glow-sm-cyan"
          >
            <Plus className="w-3.5 h-3.5" />
            <span>New Project</span>
          </button>
        </div>
      </div>

      {/* Projects Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {projects.map((proj) => {
          const isActive = proj.id === activeProjectId;
          const totalBOQ = proj.boqItems.reduce((acc, i) => acc + i.totalCost, 0);
          const avgProgress = Math.round(
            proj.phases.reduce((acc, p) => acc + p.observedPercent, 0) / (proj.phases.length || 1)
          );

          return (
            <div
              key={proj.id}
              onClick={() => onSelectProject(proj.id)}
              className={`p-4 rounded-xl border cursor-pointer transition-all flex flex-col justify-between space-y-3.5 ${
                isActive
                  ? 'bg-[#101828] border-cyan-500/70 shadow-2xl glow-sm-cyan'
                  : 'bg-[#0d131f] border-slate-800 hover:border-slate-700 hover:bg-[#0f1624]'
              }`}
            >
              <div className="space-y-2">
                <div className="flex items-start justify-between">
                  <div className="space-y-1">
                    <div className="flex items-center gap-2">
                      <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-slate-800 text-cyan-300">
                        {proj.code}
                      </span>
                      {proj.isDemo && (
                        <span className="text-[10px] font-mono px-2 py-0.5 rounded bg-amber-950 border border-amber-800 text-amber-300">
                          Demonstration Data
                        </span>
                      )}
                    </div>
                    <h3 className="text-sm font-bold text-slate-100 group-hover:text-cyan-300 transition-colors">
                      {proj.name}
                    </h3>
                  </div>

                  <div className="flex items-center gap-1">
                    <button
                      onClick={(e) => {
                        e.stopPropagation();
                        openEditModal(proj);
                      }}
                      className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-cyan-400 transition-colors"
                      title="Edit project metadata"
                    >
                      <Edit2 className="w-3.5 h-3.5" />
                    </button>
                    {!proj.isDemo && (
                      <button
                        onClick={(e) => {
                          e.stopPropagation();
                          if (confirm(`Delete project "${proj.name}"?`)) {
                            onDeleteProject(proj.id);
                          }
                        }}
                        className="p-1.5 rounded hover:bg-slate-800 text-slate-400 hover:text-red-400 transition-colors"
                        title="Delete project"
                      >
                        <Trash2 className="w-3.5 h-3.5" />
                      </button>
                    )}
                  </div>
                </div>

                <div className="space-y-1 text-xs text-slate-400 font-mono">
                  <div className="flex items-center gap-1.5 truncate">
                    <MapPin className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                    <span className="truncate">{proj.location}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Building2 className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                    <span>Type: {proj.projectType}</span>
                  </div>
                  <div className="flex items-center gap-1.5">
                    <Calendar className="w-3.5 h-3.5 text-slate-500 flex-shrink-0" />
                    <span>
                      {proj.startDate} → {proj.endDate}
                    </span>
                  </div>
                </div>
              </div>

              {/* Progress and Budget metrics */}
              <div className="pt-2 border-t border-slate-800/80 space-y-2">
                <div className="flex justify-between text-xs font-mono">
                  <span className="text-slate-400">Observed Progress</span>
                  <span className="text-cyan-300 font-bold">{avgProgress}%</span>
                </div>
                <div className="w-full bg-slate-800 h-1.5 rounded-full overflow-hidden">
                  <div
                    className="bg-cyan-400 h-full rounded-full"
                    style={{ width: `${avgProgress}%` }}
                  />
                </div>

                <div className="flex justify-between items-center text-[11px] font-mono pt-1">
                  <span className="text-slate-500">Planned Budget:</span>
                  <span className="text-slate-200 font-semibold">
                    ${proj.plannedBudget.toLocaleString()}
                  </span>
                </div>

                <div className="flex justify-between items-center text-[10px] font-mono pt-1 text-slate-500">
                  <span>{proj.boqItems.length} BOQ Items</span>
                  <span>{proj.issues.filter((i) => i.status === 'open').length} Open Issues</span>
                </div>
              </div>
            </div>
          );
        })}
      </div>

      {/* Create / Edit Modal */}
      {isModalOpen && (
        <div className="fixed inset-0 z-50 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4">
          <div className="bg-[#0d131f] border border-cyan-800 rounded-xl p-5 w-full max-w-lg shadow-2xl space-y-4 animate-in fade-in zoom-in-95">
            <div className="flex items-center justify-between pb-2 border-b border-slate-800">
              <h3 className="text-sm font-bold font-mono text-cyan-300 uppercase">
                {editingProject ? 'Edit Construction Project' : 'Create New Construction Project'}
              </h3>
              <button
                onClick={() => setIsModalOpen(false)}
                className="text-slate-400 hover:text-white text-base"
              >
                ×
              </button>
            </div>

            <div className="space-y-3 text-xs">
              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Project Title
                </label>
                <input
                  type="text"
                  value={formState.name}
                  onChange={(e) => setFormState({ ...formState, name: e.target.value })}
                  placeholder="e.g. Zenith Commercial Center - Phase 1"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 text-xs focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Project Code
                  </label>
                  <input
                    type="text"
                    value={formState.code}
                    onChange={(e) => setFormState({ ...formState, code: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Project Type
                  </label>
                  <select
                    value={formState.projectType}
                    onChange={(e) => setFormState({ ...formState, projectType: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  >
                    <option value="Commercial">Commercial</option>
                    <option value="Residential">Residential</option>
                    <option value="Industrial">Industrial</option>
                    <option value="Infrastructure">Infrastructure</option>
                    <option value="Institutional">Institutional</option>
                  </select>
                </div>
              </div>

              <div>
                <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                  Site Location
                </label>
                <input
                  type="text"
                  value={formState.location}
                  onChange={(e) => setFormState({ ...formState, location: e.target.value })}
                  placeholder="e.g. Plot 14, High-Tech Industrial Zone"
                  className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 text-xs focus:border-cyan-400"
                />
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Start Date
                  </label>
                  <input
                    type="date"
                    value={formState.startDate}
                    onChange={(e) => setFormState({ ...formState, startDate: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Target End Date
                  </label>
                  <input
                    type="date"
                    value={formState.endDate}
                    onChange={(e) => setFormState({ ...formState, endDate: e.target.value })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  />
                </div>
              </div>

              <div className="grid grid-cols-2 gap-2">
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Planned Budget ($ USD)
                  </label>
                  <input
                    type="number"
                    value={formState.plannedBudget}
                    onChange={(e) => setFormState({ ...formState, plannedBudget: Number(e.target.value) })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  />
                </div>
                <div>
                  <label className="text-[10px] uppercase font-mono text-slate-400 block mb-1">
                    Project Status
                  </label>
                  <select
                    value={formState.status}
                    onChange={(e) => setFormState({ ...formState, status: e.target.value as any })}
                    className="w-full bg-slate-900 border border-slate-700 rounded p-2 text-slate-100 font-mono text-xs focus:border-cyan-400"
                  >
                    <option value="planning">Planning</option>
                    <option value="in_progress">In Progress</option>
                    <option value="under_review">Under Review</option>
                    <option value="delayed">Delayed</option>
                    <option value="completed">Completed</option>
                  </select>
                </div>
              </div>
            </div>

            <div className="flex justify-end gap-2 pt-2 border-t border-slate-800">
              <button
                onClick={() => setIsModalOpen(false)}
                className="px-3 py-1.5 rounded text-slate-400 hover:text-white font-mono text-xs"
              >
                Cancel
              </button>
              <button
                onClick={handleSave}
                className="px-4 py-1.5 rounded bg-cyan-500 text-slate-950 font-semibold hover:bg-cyan-400 font-mono text-xs"
              >
                {editingProject ? 'Save Changes' : 'Create Project'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
