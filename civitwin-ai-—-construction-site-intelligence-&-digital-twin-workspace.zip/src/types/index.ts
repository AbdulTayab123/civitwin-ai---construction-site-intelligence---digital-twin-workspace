export type ProjectStatus = 'planning' | 'in_progress' | 'under_review' | 'delayed' | 'completed';

export type ConstructionPhaseId = 'foundation' | 'structure' | 'masonry' | 'services' | 'finishing';

export interface PhaseProgress {
  id: ConstructionPhaseId;
  name: string;
  plannedPercent: number;
  observedPercent: number; // User-entered physical completion
  aiObservedHint?: number; // AI visual estimate if available
  startDate: string;
  targetEndDate: string;
  actualEndDate?: string;
  notes?: string;
  status: 'pending' | 'active' | 'completed' | 'delayed';
  lastUpdated: string;
  verifiedByEngineer: boolean;
}

export interface BOQItem {
  id: string;
  itemCode: string;
  category: 'Earthwork' | 'Concrete & Rebar' | 'Masonry' | 'MEP Services' | 'Finishes' | 'Structural Steel' | 'General';
  description: string;
  unit: string;
  quantity: number;
  unitRate: number;
  totalCost: number;
  actualQuantityUsed?: number;
  notes?: string;
}

export interface RiskIssue {
  id: string;
  projectId: string;
  title: string;
  category: 'safety' | 'workmanship' | 'material_storage' | 'structural_observation' | 'housekeeping' | 'schedule_risk';
  severity: 'low' | 'medium' | 'high' | 'critical';
  description: string;
  evidenceImageUrl?: string;
  location: string;
  assignedTo: string;
  dueDate: string;
  status: 'open' | 'under_review' | 'resolved' | 'dismissed';
  createdAt: string;
  source: 'manual_inspection' | 'ai_image_finding';
  requiresPEVerification: boolean;
  engineeringResolutionNotes?: string;
  aiSuggestedAction?: string;
}

export interface SiteImageFinding {
  id: string;
  timestamp: string;
  imageUrl: string;
  imageTitle: string;
  projectName: string;
  activePhase: string;
  sufficientEvidence: boolean;
  siteConditionSummary: string;
  visibleWork: string[];
  visibleMaterials: Array<{
    name: string;
    category?: string;
    status: 'installed' | 'in_use' | 'stored' | string;
    estimatedQuantity?: string;
    confidence: number;
  }>;
  potentialIssues: Array<{
    title: string;
    category: 'safety' | 'workmanship' | 'material_storage' | 'structural_observation' | 'housekeeping';
    severity: 'low' | 'medium' | 'high';
    description: string;
    locationHint?: string;
    requiresEngineerVerification: boolean;
    confidence: number;
    uncertaintyNote: string;
  }>;
  uncertaintyDisclaimer: string;
  platformNotice: string;
}

export interface Project {
  id: string;
  name: string;
  code: string;
  location: string;
  projectType: 'Commercial' | 'Residential' | 'Industrial' | 'Infrastructure' | 'Institutional';
  startDate: string;
  endDate: string;
  plannedBudget: number;
  currency: string;
  status: ProjectStatus;
  isDemo: boolean;
  activePhase: ConstructionPhaseId;
  phases: PhaseProgress[];
  boqItems: BOQItem[];
  issues: RiskIssue[];
  siteFindings: SiteImageFinding[];
  createdAt: string;
  updatedAt: string;
}

export interface DigitalTwinLayerConfig {
  foundation: boolean;
  superstructure: boolean;
  slabs: boolean;
  masonry: boolean;
  mep: boolean;
  finishes: boolean;
}

export type DigitalTwinRenderMode = 'wireframe' | 'solid' | 'heatmap';
