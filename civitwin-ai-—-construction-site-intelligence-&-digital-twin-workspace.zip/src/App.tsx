import React, { useState, useEffect } from 'react';
import { Project, SiteImageFinding, RiskIssue, PhaseProgress, BOQItem, ConstructionPhaseId } from './types';
import { DEMO_PROJECT } from './data/sampleProject';
import { HeaderNav, NavTab } from './components/HeaderNav';
import { DigitalTwin3D } from './components/DigitalTwin3D';
import { MaterialQuantityTable } from './components/MaterialQuantityTable';
import { AnalyticsCharts, BottomTelemetryStatus } from './components/AnalyticsCharts';
import { AIImageReview } from './components/AIImageReview';
import { BOQManager } from './components/BOQManager';
import { ProgressTracker } from './components/ProgressTracker';
import { RiskRegister } from './components/RiskRegister';
import { ProjectWorkspace } from './components/ProjectWorkspace';
import { ProjectReportView } from './components/ProjectReportView';
import { ProductLandingModal } from './components/ProductLandingModal';
import { Info, HelpCircle } from 'lucide-react';

const STORAGE_KEY = 'civitwin_projects_v1';
const ACTIVE_PROJ_KEY = 'civitwin_active_proj_id';

export default function App() {
  // Load persisted projects or seed with demonstration project
  const [projects, setProjects] = useState<Project[]>(() => {
    try {
      const saved = localStorage.getItem(STORAGE_KEY);
      if (saved) {
        const parsed = JSON.parse(saved);
        if (Array.isArray(parsed) && parsed.length > 0) {
          return parsed;
        }
      }
    } catch (e) {
      console.warn('Could not read saved projects from localStorage:', e);
    }
    return [DEMO_PROJECT];
  });

  const [activeProjectId, setActiveProjectId] = useState<string>(() => {
    const savedId = localStorage.getItem(ACTIVE_PROJ_KEY);
    return savedId || DEMO_PROJECT.id;
  });

  const [currentTab, setCurrentTab] = useState<NavTab>('overview');
  const [hasGeminiKey, setHasGeminiKey] = useState<boolean>(true);
  const [isLandingOpen, setIsLandingOpen] = useState<boolean>(false);

  // Check health and server Gemini status
  useEffect(() => {
    fetch('/api/health')
      .then((res) => res.json())
      .then((data) => {
        setHasGeminiKey(Boolean(data.hasGeminiKey));
      })
      .catch(() => {
        setHasGeminiKey(false);
      });
  }, []);

  // Persist projects to localStorage
  useEffect(() => {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(projects));
    } catch (e) {
      console.warn('Failed to save projects to localStorage:', e);
    }
  }, [projects]);

  useEffect(() => {
    localStorage.setItem(ACTIVE_PROJ_KEY, activeProjectId);
  }, [activeProjectId]);

  const activeProject =
    projects.find((p) => p.id === activeProjectId) || projects[0] || DEMO_PROJECT;

  // Handlers for Project Mutations
  const handleUpdateActiveProject = (updatedFields: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((proj) =>
        proj.id === activeProject.id
          ? { ...proj, ...updatedFields, updatedAt: new Date().toISOString() }
          : proj
      )
    );
  };

  const handleCreateProject = (newProject: Project) => {
    setProjects((prev) => [...prev, newProject]);
    setActiveProjectId(newProject.id);
    setCurrentTab('overview');
  };

  const handleUpdateProject = (projId: string, updatedFields: Partial<Project>) => {
    setProjects((prev) =>
      prev.map((proj) => (proj.id === projId ? { ...proj, ...updatedFields } : proj))
    );
  };

  const handleDeleteProject = (projId: string) => {
    setProjects((prev) => {
      const remaining = prev.filter((proj) => proj.id !== projId);
      if (remaining.length === 0) {
        return [DEMO_PROJECT];
      }
      return remaining;
    });
    if (activeProjectId === projId) {
      setActiveProjectId(projects[0]?.id || DEMO_PROJECT.id);
    }
  };

  const handleResetDemoProject = () => {
    setProjects((prev) => {
      const others = prev.filter((p) => p.id !== DEMO_PROJECT.id);
      return [DEMO_PROJECT, ...others];
    });
    setActiveProjectId(DEMO_PROJECT.id);
  };

  // Progress Phase update
  const handleUpdatePhase = (phaseId: ConstructionPhaseId, updatedData: Partial<PhaseProgress>) => {
    const newPhases = activeProject.phases.map((ph) =>
      ph.id === phaseId ? { ...ph, ...updatedData } : ph
    );
    handleUpdateActiveProject({ phases: newPhases });
  };

  // BOQ Items update
  const handleUpdateBOQItems = (newItems: BOQItem[]) => {
    handleUpdateActiveProject({ boqItems: newItems });
  };

  // Add issue to risk register
  const handleAddIssue = (issue: RiskIssue) => {
    const newIssues = [issue, ...activeProject.issues];
    handleUpdateActiveProject({ issues: newIssues });
  };

  // Update existing issue
  const handleUpdateIssue = (issueId: string, updated: Partial<RiskIssue>) => {
    const newIssues = activeProject.issues.map((i) =>
      i.id === issueId ? { ...i, ...updated } : i
    );
    handleUpdateActiveProject({ issues: newIssues });
  };

  // Attach an AI image finding as a risk issue
  const handleAttachFindingAsIssue = (issueData: Partial<RiskIssue>) => {
    const newIssue: RiskIssue = {
      id: `issue-ai-${Date.now()}`,
      projectId: activeProject.id,
      title: issueData.title || 'Site Visual Observation',
      category: issueData.category || 'workmanship',
      severity: issueData.severity || 'medium',
      description: issueData.description || '',
      location: issueData.location || `${activeProject.name} Active Bay`,
      assignedTo: issueData.assignedTo || 'Site QA/QC Engineer',
      dueDate: issueData.dueDate || new Date().toISOString().split('T')[0],
      status: (issueData.status as any) || 'open',
      createdAt: new Date().toISOString().split('T')[0],
      source: 'ai_image_finding',
      evidenceImageUrl: issueData.evidenceImageUrl,
      requiresPEVerification: issueData.requiresPEVerification ?? true,
      aiSuggestedAction: issueData.aiSuggestedAction,
    };
    handleAddIssue(newIssue);
  };

  const handleSaveFindingRecord = (finding: SiteImageFinding) => {
    const newFindings = [finding, ...activeProject.siteFindings];
    handleUpdateActiveProject({ siteFindings: newFindings });
  };

  return (
    <div className="min-h-screen bg-[#080c14] text-slate-100 flex flex-col font-sans selection:bg-cyan-500/30 selection:text-cyan-200">
      {/* Top Header Navigation */}
      <HeaderNav
        currentTab={currentTab}
        onSelectTab={setCurrentTab}
        projects={projects}
        activeProject={activeProject}
        onSelectProject={setActiveProjectId}
        hasGeminiKey={hasGeminiKey}
      />

      {/* Main Content Viewport */}
      <main className="flex-1 max-w-[1720px] w-full mx-auto p-3 sm:p-4 md:p-5 flex flex-col">
        {/* TAB 1: OVERVIEW (Matching the User's Screenshot Design) */}
        {currentTab === 'overview' && (
          <div className="flex-1 flex flex-col space-y-4">
            {/* Top Row: Split 3 Columns (Material Quantity Table | 3D Digital Twin | Analytics Charts) */}
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-4 flex-1 min-h-[580px]">
              {/* Left Column: Material Quantity Table (3.5 cols on xl, 4 on lg) */}
              <div className="lg:col-span-4 xl:col-span-3 h-[520px] lg:h-auto">
                <MaterialQuantityTable
                  items={activeProject.boqItems}
                  onOpenBOQTab={() => setCurrentTab('materials')}
                />
              </div>

              {/* Center Column: 3D Digital Twin Architectural BIM Model (5.5 cols on xl, 5 on lg) */}
              <div className="lg:col-span-5 xl:col-span-6 h-[520px] lg:h-auto min-h-[440px]">
                <DigitalTwin3D
                  activePhase={activeProject.activePhase}
                  openIssuesCount={activeProject.issues.length}
                />
              </div>

              {/* Right Column: Analytics & Consumption Charts (3 cols) */}
              <div className="lg:col-span-3 xl:col-span-3 flex flex-col">
                <AnalyticsCharts project={activeProject} />
              </div>
            </div>

            {/* Bottom Row: Telemetry Status Panels (matching screenshot bottom gauges) */}
            <div>
              <BottomTelemetryStatus project={activeProject} />
            </div>
          </div>
        )}

        {/* TAB 2: PROJECTS WORKSPACE */}
        {currentTab === 'projects' && (
          <ProjectWorkspace
            projects={projects}
            activeProjectId={activeProjectId}
            onSelectProject={(id) => {
              setActiveProjectId(id);
              setCurrentTab('overview');
            }}
            onCreateProject={handleCreateProject}
            onUpdateProject={handleUpdateProject}
            onDeleteProject={handleDeleteProject}
            onResetDemoProject={handleResetDemoProject}
          />
        )}

        {/* TAB 3: MATERIAL DATA & BOQ INTELLIGENCE */}
        {currentTab === 'materials' && (
          <BOQManager
            project={activeProject}
            onUpdateBOQItems={handleUpdateBOQItems}
            onUpdatePlannedBudget={(budget) => handleUpdateActiveProject({ plannedBudget: budget })}
          />
        )}

        {/* TAB 4: AI SITE IMAGE REVIEW */}
        {currentTab === 'ai_analysis' && (
          <AIImageReview
            project={activeProject}
            onAttachFindingAsIssue={handleAttachFindingAsIssue}
            onSaveFindingRecord={handleSaveFindingRecord}
          />
        )}

        {/* TAB 5: PROGRESS TRACKER */}
        {currentTab === 'progress' && (
          <ProgressTracker
            project={activeProject}
            onUpdatePhase={handleUpdatePhase}
          />
        )}

        {/* TAB 6: RISK AND ISSUE REGISTER */}
        {currentTab === 'risks' && (
          <RiskRegister
            project={activeProject}
            onUpdateIssue={handleUpdateIssue}
            onAddIssue={handleAddIssue}
          />
        )}

        {/* TAB 7: EXECUTIVE PROJECT REPORTS */}
        {currentTab === 'reports' && (
          <ProjectReportView project={activeProject} />
        )}
      </main>

      {/* Persistent Engineering Governance Bottom Bar */}
      <footer className="bg-[#060a12] border-t border-slate-900 px-4 py-2 text-[11px] font-mono text-slate-500 flex flex-col sm:flex-row items-center justify-between gap-2">
        <div className="flex items-center gap-2">
          <span className="w-1.5 h-1.5 rounded-full bg-cyan-400"></span>
          <span>
            CiviTwin AI Platform • Planning & Decision-Support System (Non-certifying)
          </span>
        </div>

        <div className="flex items-center gap-4">
          <button
            onClick={() => setIsLandingOpen(true)}
            className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1 transition-colors"
          >
            <HelpCircle className="w-3.5 h-3.5" />
            <span>Platform Overview & Engineering Rules</span>
          </button>
          <span>v2.4.0 Engine</span>
        </div>
      </footer>

      {/* Product Landing / Platform Introduction Modal */}
      <ProductLandingModal
        isOpen={isLandingOpen}
        onClose={() => setIsLandingOpen(false)}
        onOpenWorkspace={() => {
          setIsLandingOpen(false);
          setCurrentTab('overview');
        }}
      />
    </div>
  );
}
