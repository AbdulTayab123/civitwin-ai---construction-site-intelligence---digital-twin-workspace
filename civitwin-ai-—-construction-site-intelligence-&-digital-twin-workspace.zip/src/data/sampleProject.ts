import { Project, SiteImageFinding } from '../types';

// High-fidelity construction illustration / photo sample data URIs for instant preview & inspection
export const SAMPLE_SITE_IMAGES = [
  {
    id: 'sample-rebar-mat',
    title: 'Level 2 Suspended Slab Rebar & Conduits Inspection',
    phase: 'structure',
    description: 'Post-placement inspection of top reinforcement mat, shear links, and embedded PVC electrical sleeves prior to planned slab pour.',
    url: 'https://images.unsplash.com/photo-1541888946425-d0fbb18615f8?auto=format&fit=crop&w=1200&q=80',
    mockFindings: {
      sufficientEvidence: true,
      siteConditionSummary: 'Reinforcement mat laid over plywood formwork. High-density steel rebar tied at intersections with visible electrical conduit routing and spacer blocks placed.',
      visibleWork: [
        'Top layer rebar grid installed and tied with annealed wire',
        'PVC electrical conduit sleeves secured along perimeter bay',
        'Timber formwork perimeter edge boards secured'
      ],
      visibleMaterials: [
        { name: 'Deformed High-Yield Rebar (T16 & T12)', category: 'Concrete & Rebar', status: 'installed', estimatedQuantity: '4.8 tonnes (approx. bay area)', confidence: 92 },
        { name: 'Rigid PVC Electrical Conduit', category: 'MEP Services', status: 'installed', estimatedQuantity: '65 linear meters', confidence: 88 },
        { name: 'Concrete Cover Blocks / Spacers', category: 'Concrete & Rebar', status: 'installed', estimatedQuantity: 'Visible at 800mm centers', confidence: 78 },
        { name: 'Film-Faced Plywood Formwork', category: 'General', status: 'in_use', estimatedQuantity: 'Complete bay coverage', confidence: 95 }
      ],
      potentialIssues: [
        {
          title: 'Concrete Cover Depth Verification Required',
          category: 'workmanship',
          severity: 'medium',
          description: 'Spacers visible, but cover height cannot be calibrated from a 2D photograph. Requires physical depth gauge check before pour.',
          locationHint: 'West edge perimeter slab overhang',
          requiresEngineerVerification: true,
          confidence: 84,
          uncertaintyNote: 'Photographic angle cannot measure millimeter-level bottom and side cover clearances.'
        },
        {
          title: 'Debris Clearance in Formwork Cavity',
          category: 'housekeeping',
          severity: 'low',
          description: 'Small wood shavings and tie wire cutoffs visible near bottom corners; blow-out or vacuum required prior to concrete placement.',
          locationHint: 'Near column stub tie-in bay 3B',
          requiresEngineerVerification: true,
          confidence: 76,
          uncertaintyNote: 'Shadows obscure lower form corners.'
        }
      ],
      uncertaintyDisclaimer: 'Visual observation only. AI cannot determine steel tensile grade, lap length structural compliance, or weld strength. Must be physically checked by Site Engineer.',
      platformNotice: 'Advisory planning decision-support tool. Not a certified structural engineering inspection.'
    }
  },
  {
    id: 'sample-foundation-pour',
    title: 'Raft Foundation Excavation & Blinding Concrete',
    phase: 'foundation',
    description: 'Substructure excavation inspection showing mass concrete blinding layer, sump pits, and perimeter earth shoring.',
    url: 'https://images.unsplash.com/photo-1504307651254-35680f356dfd?auto=format&fit=crop&w=1200&q=80',
    mockFindings: {
      sufficientEvidence: true,
      siteConditionSummary: 'Foundation pit graded with plain concrete blinding layer placed. Perimeter sheet piling / shoring wall installed. Earth excavation completed to design datum.',
      visibleWork: [
        'Subgrade compaction and blinding concrete leveling complete',
        'Dewatering pump and flexible discharge hose operating in corner sump pit',
        'Excavator positioned on top berm'
      ],
      visibleMaterials: [
        { name: 'Blinding Concrete (Grade C15)', category: 'Concrete & Rebar', status: 'installed', estimatedQuantity: '450 m² slab footprint', confidence: 91 },
        { name: 'Interlocking Steel Sheet Piles', category: 'Earthwork', status: 'in_use', estimatedQuantity: '60 perimeter meters', confidence: 89 },
        { name: 'Submersible Sump Pump', category: 'General', status: 'in_use', estimatedQuantity: '1 unit active', confidence: 94 }
      ],
      potentialIssues: [
        {
          title: 'Water Seepage Along Shoring Interlock',
          category: 'structural_observation',
          severity: 'high',
          description: 'Visible localized damp patch and shallow ponding near north corner sheet pile seam. Monitor for fines washout.',
          locationHint: 'North retaining wall seam',
          requiresEngineerVerification: true,
          confidence: 81,
          uncertaintyNote: 'Surface moisture pattern visible; hydrostatic head and flow rate cannot be determined optically.'
        }
      ],
      uncertaintyDisclaimer: 'Bearing capacity and soil strata density cannot be assessed by visual imaging. Requires certified geotechnical laboratory soil reports.',
      platformNotice: 'Advisory planning decision-support tool. Not a certified structural engineering inspection.'
    }
  },
  {
    id: 'sample-structural-steel',
    title: 'Superstructure Framing & Shear Wall Formwork',
    phase: 'structure',
    description: 'Overview of multi-story cast-in-place concrete columns, shear walls, and perimeter safety nets.',
    url: 'https://images.unsplash.com/photo-1590496793929-36417d3117de?auto=format&fit=crop&w=1200&q=80',
    mockFindings: {
      sufficientEvidence: true,
      siteConditionSummary: 'Reinforced concrete framing on 3rd floor level underway. Perimeter edge protection scaffold erected. Steel formwork panels aligned for shear wall core.',
      visibleWork: [
        'Erection of climbing modular formwork for lift core',
        'Tower crane lifting rebar bundle to active working platform',
        'Edge guardrails and safety catch-netting attached to slab edge'
      ],
      visibleMaterials: [
        { name: 'Steel Core Formwork Panels', category: 'General', status: 'in_use', estimatedQuantity: 'Full elevator core', confidence: 94 },
        { name: 'Pre-tied Column Reinforcement Cages', category: 'Concrete & Rebar', status: 'stored', estimatedQuantity: '6 column sets', confidence: 90 },
        { name: 'Perimeter Edge Guardrails & Mesh', category: 'General', status: 'installed', estimatedQuantity: '120 linear meters', confidence: 96 }
      ],
      potentialIssues: [
        {
          title: 'Formwork Tie Rod Tightness Verification',
          category: 'safety',
          severity: 'medium',
          description: 'Core shuttering panels erected; verify torque and waler clamp alignment prior to pour to avoid form blowout under wet concrete pressure.',
          locationHint: 'Elevator Core South Shear Wall',
          requiresEngineerVerification: true,
          confidence: 77,
          uncertaintyNote: 'Camera angle prevents direct view of waler tie pins on internal face.'
        }
      ],
      uncertaintyDisclaimer: 'Formwork lateral pressure resistance and wind brace anchor stability must be certified by the Temporary Works Coordinator.',
      platformNotice: 'Advisory planning decision-support tool. Not a certified structural engineering inspection.'
    }
  }
];

export const DEMO_PROJECT: Project = {
  id: 'demo-apex-tower-b',
  name: 'Apex Tower B — Digital Twin Demonstrator',
  code: 'CIVI-TWIN-DEMO-01',
  location: 'Sector 42 Innovation Corridor, Metro District',
  projectType: 'Commercial',
  startDate: '2025-08-01',
  endDate: '2026-12-15',
  plannedBudget: 4850000,
  currency: 'USD',
  status: 'in_progress',
  isDemo: true,
  activePhase: 'structure',
  phases: [
    {
      id: 'foundation',
      name: 'Foundation & Substructure',
      plannedPercent: 100,
      observedPercent: 100,
      aiObservedHint: 100,
      startDate: '2025-08-01',
      targetEndDate: '2025-11-15',
      actualEndDate: '2025-11-20',
      status: 'completed',
      lastUpdated: '2025-11-20',
      verifiedByEngineer: true,
      notes: 'Raft foundation and dewatering completed. 5-day variance due to unexpected subterranean water seam.'
    },
    {
      id: 'structure',
      name: 'Superstructure & RCC Frame',
      plannedPercent: 68,
      observedPercent: 62,
      aiObservedHint: 60,
      startDate: '2025-11-16',
      targetEndDate: '2026-05-30',
      status: 'active',
      lastUpdated: '2026-04-10',
      verifiedByEngineer: true,
      notes: 'Level 4 slab cast. Level 5 column rebar cages being tied. 6% physical lag behind scheduled baseline.'
    },
    {
      id: 'masonry',
      name: 'Masonry & External Enclosure',
      plannedPercent: 35,
      observedPercent: 28,
      aiObservedHint: 25,
      startDate: '2026-02-01',
      targetEndDate: '2026-07-31',
      status: 'active',
      lastUpdated: '2026-04-08',
      verifiedByEngineer: true,
      notes: 'AAC blockwork ongoing up to Level 2. Window sub-frames delivered.'
    },
    {
      id: 'services',
      name: 'MEP Services (HVAC, Electrical, Plumbing)',
      plannedPercent: 25,
      observedPercent: 18,
      aiObservedHint: 15,
      startDate: '2026-03-01',
      targetEndDate: '2026-09-30',
      status: 'active',
      lastUpdated: '2026-04-05',
      verifiedByEngineer: false,
      notes: 'Basement fire fighting ring mains installed. Level 1 conduit rough-ins in progress.'
    },
    {
      id: 'finishing',
      name: 'Architectural Finishes & Fit-out',
      plannedPercent: 5,
      observedPercent: 0,
      startDate: '2026-06-01',
      targetEndDate: '2026-12-15',
      status: 'pending',
      lastUpdated: '2026-04-01',
      verifiedByEngineer: false,
      notes: 'Pending completion of dry masonry and preliminary MEP pressure testing.'
    }
  ],
  boqItems: [
    {
      id: 'boq-001',
      itemCode: 'CONC-C35',
      category: 'Concrete & Rebar',
      description: 'Ready-Mix Concrete Grade C35/45 for suspended slabs and shear walls (Illustrative sample rate)',
      unit: 'm³',
      quantity: 3200,
      unitRate: 145,
      totalCost: 464000,
      actualQuantityUsed: 1980,
      notes: 'Certified mix design with waterproofing admixture'
    },
    {
      id: 'boq-002',
      itemCode: 'STEEL-T500',
      category: 'Concrete & Rebar',
      description: 'High-Yield Deformed Steel Reinforcement Fe500D (Cutting, bending, tying in place)',
      unit: 'tonnes',
      quantity: 380,
      unitRate: 980,
      totalCost: 372400,
      actualQuantityUsed: 235,
      notes: 'Mill test certificates verified for heat lots'
    },
    {
      id: 'boq-003',
      itemCode: 'EARTH-EXC',
      category: 'Earthwork',
      description: 'Bulk foundation excavation in mixed soil and disintegrated rock including haulage',
      unit: 'm³',
      quantity: 12500,
      unitRate: 18,
      totalCost: 225000,
      actualQuantityUsed: 12500,
      notes: 'Complete'
    },
    {
      id: 'boq-004',
      itemCode: 'MAS-AAC200',
      category: 'Masonry',
      description: 'Autoclaved Aerated Concrete (AAC) blocks 200mm thickness laid with thin-bed adhesive',
      unit: 'm²',
      quantity: 4800,
      unitRate: 42,
      totalCost: 201600,
      actualQuantityUsed: 1350,
      notes: 'Compressive strength 4.0 N/mm²'
    },
    {
      id: 'boq-005',
      itemCode: 'MEP-HVAC-DUCT',
      category: 'MEP Services',
      description: 'Galvanized iron rectangular ductwork including acoustic lining and hangers',
      unit: 'm²',
      quantity: 2600,
      unitRate: 65,
      totalCost: 169000,
      actualQuantityUsed: 420,
      notes: 'Supply & fabrication underway off-site'
    },
    {
      id: 'boq-006',
      itemCode: 'DRYWALL-FIRE',
      category: 'Finishes',
      description: 'Fire-rated gypsum drywall partition double-layer on 75mm GI stud framing',
      unit: 'm²',
      quantity: 3500,
      unitRate: 52,
      totalCost: 182000,
      actualQuantityUsed: 0,
      notes: 'Awaiting building enclosure dry status'
    },
    {
      id: 'boq-007',
      itemCode: 'SHORING-SHEET',
      category: 'Earthwork',
      description: 'Temporary sheet pile shoring with tieback anchors along perimeter',
      unit: 'linear m',
      quantity: 210,
      unitRate: 620,
      totalCost: 130200,
      actualQuantityUsed: 210,
      notes: 'De-stressing planned at backfill stage'
    },
    {
      id: 'boq-008',
      itemCode: 'PLUMB-PPR',
      category: 'MEP Services',
      description: 'PPR-C cold and hot water supply piping network PN16 with thermal insulation',
      unit: 'linear m',
      quantity: 3400,
      unitRate: 38,
      totalCost: 129200,
      actualQuantityUsed: 650,
      notes: 'Hydrostatic pressure testing at 10 bar required'
    }
  ],
  issues: [
    {
      id: 'issue-01',
      projectId: 'demo-apex-tower-b',
      title: 'Level 3 Grid C-4 Rebar Cover Block Deficiency',
      category: 'workmanship',
      severity: 'medium',
      description: 'Inspection revealed spacing of cover blocks exceeds 1.0m on column south face; risk of rebar exposure to exterior weather.',
      location: 'Level 3, Column C-4 south face',
      assignedTo: 'M. Chen (QA/QC Engineer)',
      dueDate: '2026-10-18',
      status: 'open',
      createdAt: '2026-10-10',
      source: 'manual_inspection',
      requiresPEVerification: true,
      aiSuggestedAction: 'Install 40mm heavy-duty fiber concrete cover blocks at max 600mm stagger prior to column shutter placement.'
    },
    {
      id: 'issue-02',
      projectId: 'demo-apex-tower-b',
      title: 'Water Seepage in North Shoring Piles',
      category: 'structural_observation',
      severity: 'high',
      description: 'Groundwater infiltration observed between interlocking sheet piles 14 & 15. Requires geotechnical inspection to verify no fines loss behind wall.',
      location: 'Basement Level 2, North Wall Shoring',
      assignedTo: 'Dr. R. Vance (Geotechnical Consultant)',
      dueDate: '2026-10-15',
      status: 'under_review',
      createdAt: '2026-10-11',
      source: 'ai_image_finding',
      requiresPEVerification: true,
      aiSuggestedAction: 'Deploy grout injection packers and continuous sump monitoring to verify no void creation in subsoil.'
    },
    {
      id: 'issue-03',
      projectId: 'demo-apex-tower-b',
      title: 'Scaffold Toeboard Missing on Level 4 West Edge',
      category: 'safety',
      severity: 'high',
      description: 'Working platform missing 150mm kickboard/toeboard along 12m perimeter bay; immediate falling object hazard to ground crew below.',
      location: 'Level 4 Working Deck, West Bay',
      assignedTo: 'S. Al-Mansoor (Safety Officer)',
      dueDate: '2026-10-14',
      status: 'open',
      createdAt: '2026-10-12',
      source: 'manual_inspection',
      requiresPEVerification: false,
      aiSuggestedAction: 'Halt work in drop zone, immediately install timber toeboards and double handrail per OSHA/HSE guidelines.'
    },
    {
      id: 'issue-04',
      projectId: 'demo-apex-tower-b',
      title: 'AAC Blockwork Moisture Protection in Staging Area',
      category: 'material_storage',
      severity: 'low',
      description: 'Delivered pallets of AAC blocks stored without tarpaulin covers exposed to seasonal rain drizzle.',
      location: 'Ground Laydown Yard 2',
      assignedTo: 'K. Patel (Site Materials Supervisor)',
      dueDate: '2026-10-14',
      status: 'resolved',
      createdAt: '2026-10-09',
      source: 'ai_image_finding',
      requiresPEVerification: false,
      engineeringResolutionNotes: 'Pallets elevated on timber bearers and covered with 200gsm weatherproof tarpaulins. Verified by Materials QA.',
      aiSuggestedAction: 'Ensure elevated pallet stacking to prevent capillary suction from muddy ground.'
    }
  ],
  siteFindings: [
    {
      id: 'finding-01',
      timestamp: '2026-10-11T14:30:00Z',
      imageUrl: SAMPLE_SITE_IMAGES[0].url,
      imageTitle: 'Level 2 Suspended Slab Inspection Photo',
      projectName: 'Apex Tower B',
      activePhase: 'structure',
      sufficientEvidence: true,
      siteConditionSummary: 'Top reinforcement mat laid over formwork with conduit routing and perimeter guardrails visible.',
      visibleWork: [
        'Steel rebar mat grid tied at regular spacing',
        'PVC electrical conduit sleeves routed across bay',
        'Edge formwork stop-ends secured'
      ],
      visibleMaterials: [
        { name: 'Reinforcement Steel Bars', category: 'Concrete & Rebar', status: 'installed', estimatedQuantity: 'Approx. 5 tonnes in active bay', confidence: 91 },
        { name: 'PVC Conduits', category: 'MEP Services', status: 'installed', estimatedQuantity: '65m', confidence: 88 }
      ],
      potentialIssues: [
        {
          title: 'Cover block depth physical audit required',
          category: 'workmanship',
          severity: 'medium',
          description: 'Spacers are present but exact bottom clearance cannot be validated from 2D photography.',
          locationHint: 'Perimeter cantilever zone',
          requiresEngineerVerification: true,
          confidence: 83,
          uncertaintyNote: 'Photographic angle cannot measure millimeter-level concrete cover.'
        }
      ],
      uncertaintyDisclaimer: 'Planning decision-support observation only. Not a licensed structural engineering certificate.',
      platformNotice: 'Visual planning tool. Structural calculations and load capacity require physical PE verification.'
    }
  ],
  createdAt: '2025-08-01T08:00:00Z',
  updatedAt: '2026-10-13T09:00:00Z'
};

export const SAMPLE_CSV_TEMPLATE = `Item Code,Category,Description,Unit,Quantity,Unit Rate
CONC-C35,Concrete & Rebar,Ready-Mix Concrete Grade C35 for suspended slabs,m3,3200,145.00
STEEL-T500,Concrete & Rebar,High-Yield Deformed Steel Rebar Fe500D tied in place,tonnes,380,980.00
EARTH-EXC,Earthwork,Bulk excavation in mixed strata including disposal,m3,12500,18.00
MAS-AAC200,Masonry,AAC blockwork 200mm with polymer-modified adhesive,m2,4800,42.00
MEP-HVAC-DUCT,MEP Services,Galvanized iron rectangular ductwork with insulation,m2,2600,65.00
DRYWALL-FIRE,Finishes,Double layer fire-rated gypsum drywall on GI studs,m2,3500,52.00
`;
