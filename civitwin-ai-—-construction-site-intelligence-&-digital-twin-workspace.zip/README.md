# CiviTwin AI — Construction Site Intelligence & Digital Twin Workspace

> **Civil Engineering Decision-Support Platform**  
> *Interactive 3D Digital Twin • Multimodal Gemini Site Image Intelligence • Deterministic BOQ & Cost Analytics • Phase Progress Timeline • Risk & Issue Register*

---

## 1. Statutory Notice & Engineering Boundary

**CiviTwin AI is an advisory planning, quantity intelligence, and digital twin decision-support system.**  
- **It is NOT a licensed structural engineering authority.**  
- AI multimodal models **never certify** structural load capacity, foundation soil bearing strata, rebar yield stress, weld integrity, tie-spacing compliance, or statutory building control approvals.
- A single photograph does **not** prove overall project completion percentage.
- All safety-critical structural findings, high-severity non-conformances, and formwork striking approvals **require on-site physical evaluation and written sign-off by a licensed Professional Engineer (PE / SE)**.

---

## 2. Core Functional Modules

### A. Project Workspace
- Full CRUD lifecycle for civil construction projects.
- Captures Project Title, Code, Site Location, Project Type (Commercial, Residential, Infrastructure, Industrial, Institutional), Start/Target Completion Dates, Planned Budget, and Active Phase.
- Includes a realistic demonstration project (`Apex Tower B`) explicitly marked as **Demonstration Data**, with a 1-click reset function.
- Persisted locally with automatic schema preservation.

### B. Interactive 3D Digital Twin Workspace (Three.js)
- Real-time CAD/BIM-inspired wireframe, volumetric, and AI confidence heatmap render modes.
- Structural layer isolation:
  - **Foundation:** Raft foundation slab, grade beams, column pedestals.
  - **Superstructure:** Multi-story column grid, central elevator shear wall core, perimeter framing beams.
  - **Floor Slabs:** Suspended floor plates across levels 1 through 4.
  - **Masonry:** AAC blockwork enclosures and partitions.
  - **MEP Services:** Primary HVAC supply air ducting and main conduits.
- Interactive element raycasting: click any building component to inspect material grade, volume/quantity, and QA inspection status.
- Inspection Hotspot Pins: 3D coordinates anchored to real site observations and open non-conformance records.

### C. AI Site Image Review (Gemini 3.8 Flash Multimodal Model)
- Secure full-stack server proxy (`POST /api/analyze-site-image`).
- Accepts construction site photographs and queries Gemini multimodal vision models.
- Classifies:
  - Visible operations underway.
  - Observed materials and equipment inventory (with confidence scores and storage status).
  - Potential quality, safety, and workmanship issues.
  - Uncertainty factors (e.g. angle of shot, obscured substrates, cover block tolerances).
- 1-click **Log to Risk Register** workflow converting visual findings into actionable items.

### D. Construction Progress Tracker
- Phase-by-phase tracking: Foundation, Structure, Masonry, Services, Finishing.
- Real-time planned baseline vs. reported observed physical completion.
- Clear separation between human engineer verified physical measurements and AI visual photo hints.
- Deterministic delay calculation flagging schedule slippage.

### E. Bill of Quantities (BOQ) & Cost Intelligence
- Import standard Bill of Quantities via CSV (Item Code, Category, Description, Unit, Quantity, Unit Rate).
- Row validation: automatically identifies missing descriptions, units, and non-numeric quantities or rates.
- Deterministic calculation: `Item Total = Quantity × Unit Rate`.
- Compares total estimated expenditure against target project budget.
- Editable quantities and unit rates with downloadable CSV export and sample template generator.

### F. Risk & Issue Register
- Logs severity (Low, Medium, High, Critical), category, location, assignee, due date, status, and evidence image.
- Enforces mandatory Professional Engineer (PE) sign-off on safety-critical structural observations.
- Server-side **AI Priorities Advisor** (`POST /api/suggest-risk-priorities`) generating targeted inspection check-questions for active project phases.

### G. Executive Project Intelligence Reports
- Printable, clean audit document formatted for landscape and portrait printing.
- Tabular summaries of milestones, financial allocations, and open risks.
- Exportable CSV report.
- Strictly avoids generating fake signatures, seals, or artificial compliance credentials.

---

## 3. Technology Architecture

- **Frontend:** React 19, TypeScript, Vite, Tailwind CSS v4, Lucide Icons.
- **3D Engine:** Three.js with custom isometric raycasting, lighting, and layer management.
- **Backend:** Express full-stack server mounted via Vite dev middlewares (`server.ts`).
- **AI SDK:** `@google/genai` TypeScript SDK utilizing `gemini-3.8-flash` with structured JSON schema enforcement.
- **CSV Engine:** PapaParse with custom row validation.

---

## 4. Setup & Running Locally

### Prerequisites
- Node.js 18+ or 20+
- npm or pnpm

### Installation
```bash
# 1. Install dependencies
npm install

# 2. Configure Environment
cp .env.example .env
# Set your GEMINI_API_KEY in .env or the Secrets panel

# 3. Start Full-Stack Dev Server (runs on Port 3000)
npm run dev

# 4. Production Build
npm run build
npm start
```

---

## 5. Sample CSV Format

You can import CSV files matching this schema (a sample can also be downloaded directly from the BOQ tab):

```csv
Item Code,Category,Description,Unit,Quantity,Unit Rate
CONC-C35,Concrete & Rebar,Ready-Mix Concrete Grade C35 for suspended slabs,m3,3200,145.00
STEEL-T500,Concrete & Rebar,High-Yield Deformed Steel Rebar Fe500D tied in place,tonnes,380,980.00
EARTH-EXC,Earthwork,Bulk excavation in mixed strata including disposal,m3,12500,18.00
MAS-AAC200,Masonry,AAC blockwork 200mm with polymer-modified adhesive,m2,4800,42.00
MEP-HVAC-DUCT,MEP Services,Galvanized iron rectangular ductwork with insulation,m2,2600,65.00
DRYWALL-FIRE,Finishes,Double layer fire-rated gypsum drywall on GI studs,m2,3500,52.00
```
