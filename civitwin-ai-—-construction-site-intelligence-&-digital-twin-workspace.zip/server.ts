import express, { Request, Response } from 'express';
import dotenv from 'dotenv';
import path from 'path';
import { fileURLToPath } from 'url';
import { GoogleGenAI, Type } from '@google/genai';

dotenv.config();

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '50mb' }));
app.use(express.urlencoded({ extended: true, limit: '50mb' }));

// Initialize GoogleGenAI SDK if key is configured
const apiKey = process.env.GEMINI_API_KEY;
let ai: GoogleGenAI | null = null;
if (apiKey) {
  ai = new GoogleGenAI({
    apiKey,
    httpOptions: {
      headers: {
        'User-Agent': 'aistudio-build',
      },
    },
  });
}

// Health check endpoint
app.get('/api/health', (_req: Request, res: Response) => {
  res.json({
    status: 'ok',
    hasGeminiKey: Boolean(apiKey),
    timestamp: new Date().toISOString(),
  });
});

// AI Site Image Analysis endpoint
app.post('/api/analyze-site-image', async (req: Request, res: Response) => {
  try {
    const { imageBase64, mimeType = 'image/jpeg', projectName, currentPhase, promptContext } = req.body;

    if (!imageBase64) {
      return res.status(400).json({ error: 'Image data is required (base64 string).' });
    }

    // Strip data URI prefix if present
    const base64Data = imageBase64.replace(/^data:image\/[a-zA-Z0-9+.-]+;base64,/, '');

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server. Please ensure GEMINI_API_KEY is configured in Secrets.',
      });
    }

    const systemInstruction = `You are CiviTwin AI's civil engineering visual inspection assistant.
CRITICAL ENGINEERING GOVERNING PRINCIPLES:
1. You are a visual planning and decision-support assistant, NEVER a licensed structural engineering authority.
2. NEVER claim or imply that a single photograph proves the completion percentage of an entire project.
3. NEVER claim that concrete compressive strength, rebar grade, tie spacing adequacy, foundation bearing capacity, or structural code compliance has been professionally certified by AI.
4. If image resolution, lighting, or framing makes an element ambiguous, declare "INSUFFICIENT_EVIDENCE" or detail the uncertainty rather than fabricating details.
5. Provide honest confidence scores (0-100%) and explain uncertainty factors (e.g. angle of shot, occluded elements, surface finish obscuring substrate).
6. Separate visible observations (e.g. formwork erected, steel bars stockpiled) from risks requiring human professional engineer review.`;

    const userPromptText = `Examine this construction site image.
Project Context: ${projectName || 'General Construction Project'}
Active Phase: ${currentPhase || 'Underway'}
Additional Context: ${promptContext || 'Routine progress and quality inspection.'}

Please produce a comprehensive, structured civil engineering inspection review with:
- visibleWork: list of visible activities underway or completed in this frame
- visibleMaterials: materials/equipment seen with quantity estimate or count if visible, storage status ('stored' | 'in_use' | 'installed'), and confidence score
- potentialIssues: potential quality, safety, housekeeping, or structural visual observations requiring physical human engineer review
- confidenceBreakdown: explain what is visible vs what cannot be verified from this angle
- siteConditionSummary: 2-3 sentence technical summary
- sufficientEvidence: boolean whether this image provides actionable visual clarity`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: {
        parts: [
          {
            inlineData: {
              data: base64Data,
              mimeType: mimeType || 'image/jpeg',
            },
          },
          {
            text: userPromptText,
          },
        ],
      },
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            sufficientEvidence: {
              type: Type.BOOLEAN,
              description: 'Whether the image has adequate visual clarity and framing for engineering review',
            },
            siteConditionSummary: {
              type: Type.STRING,
              description: 'Clear, concise summary of site activities visible in this frame',
            },
            visibleWork: {
              type: Type.ARRAY,
              items: { type: Type.STRING },
              description: 'Visible construction work or operations in progress',
            },
            visibleMaterials: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  name: { type: Type.STRING },
                  category: { type: Type.STRING },
                  status: { type: Type.STRING, description: 'installed, in_use, or stored' },
                  estimatedQuantity: { type: Type.STRING },
                  confidence: { type: Type.INTEGER, description: 'Confidence between 0 and 100' },
                },
                required: ['name', 'status', 'confidence'],
              },
            },
            potentialIssues: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  title: { type: Type.STRING },
                  category: {
                    type: Type.STRING,
                    description: 'safety, workmanship, material_storage, structural_observation, or housekeeping',
                  },
                  severity: { type: Type.STRING, description: 'low, medium, or high' },
                  description: { type: Type.STRING },
                  locationHint: { type: Type.STRING },
                  requiresEngineerVerification: { type: Type.BOOLEAN },
                  confidence: { type: Type.INTEGER },
                  uncertaintyNote: { type: Type.STRING },
                },
                required: ['title', 'category', 'severity', 'description', 'requiresEngineerVerification', 'confidence', 'uncertaintyNote'],
              },
            },
            uncertaintyDisclaimer: {
              type: Type.STRING,
              description: 'Explicit explanation of visual limitations and mandatory human engineer physical verification',
            },
          },
          required: [
            'sufficientEvidence',
            'siteConditionSummary',
            'visibleWork',
            'visibleMaterials',
            'potentialIssues',
            'uncertaintyDisclaimer',
          ],
        },
      },
    });

    const rawText = response.text || '{}';
    let findings;
    try {
      findings = JSON.parse(rawText);
    } catch {
      findings = {
        sufficientEvidence: true,
        siteConditionSummary: rawText,
        visibleWork: ['Visual analysis conducted'],
        visibleMaterials: [],
        potentialIssues: [],
        uncertaintyDisclaimer:
          'Automated inspection note: All findings require on-site physical evaluation by a licensed Professional Engineer.',
      };
    }

    // Always append authoritative platform disclaimer
    findings.platformNotice =
      'CiviTwin AI is an advisory planning and digital twin decision-support system. It does not replace structural calculations, licensed professional engineering certifications, or statutory building control inspections.';

    return res.json(findings);
  } catch (error: any) {
    console.error('Image analysis error:', error);
    return res.status(500).json({
      error: 'Failed to analyze site image with Gemini model: ' + (error?.message || String(error)),
    });
  }
});

// AI Risk Prioritization and Engineering Questions generator
app.post('/api/suggest-risk-priorities', async (req: Request, res: Response) => {
  try {
    const { projectContext, activePhase, openIssues, boqVariance } = req.body;

    if (!ai) {
      return res.status(503).json({
        error: 'Gemini API is not configured on the server.',
      });
    }

    const systemInstruction = `You are a Senior Civil Project Intelligence Advisor for CiviTwin AI.
Provide rigorous, safety-conscious engineering questions and prioritized check-items based strictly on the project data provided.
Do not certify structural safety. Emphasize items requiring licensed geotechnical, structural, or MEP sign-off.`;

    const promptText = `Project: ${JSON.stringify(projectContext || {})}
Current Phase: ${activePhase || 'Structure'}
Open Issues / Site Observations: ${JSON.stringify(openIssues || [])}
BOQ Cost Variance: ${JSON.stringify(boqVariance || {})}

Suggest:
1. Top 3 to 5 targeted inspection questions for the project engineer before proceeding to next phase sign-off.
2. High-priority risk watch-points (e.g. curing intervals, rebar cover depth, material delivery bottleneck, weather exposure).
3. Clear reminder on mandatory professional engineering sign-offs.`;

    const response = await ai.models.generateContent({
      model: 'gemini-3.8-flash',
      contents: promptText,
      config: {
        systemInstruction,
        responseMimeType: 'application/json',
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            inspectionQuestions: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  discipline: { type: Type.STRING },
                  question: { type: Type.STRING },
                  criticality: { type: Type.STRING, description: 'routine, elevated, or safety_critical' },
                  standardRef: { type: Type.STRING },
                },
                required: ['discipline', 'question', 'criticality'],
              },
            },
            riskWatchpoints: {
              type: Type.ARRAY,
              items: {
                type: Type.OBJECT,
                properties: {
                  area: { type: Type.STRING },
                  riskDescription: { type: Type.STRING },
                  mitigationAction: { type: Type.STRING },
                  requiredSignoffRole: { type: Type.STRING },
                },
                required: ['area', 'riskDescription', 'mitigationAction', 'requiredSignoffRole'],
              },
            },
            engineeringGovernanceNote: { type: Type.STRING },
          },
          required: ['inspectionQuestions', 'riskWatchpoints', 'engineeringGovernanceNote'],
        },
      },
    });

    const parsed = JSON.parse(response.text || '{}');
    return res.json(parsed);
  } catch (error: any) {
    console.error('Risk prioritization error:', error);
    return res.status(500).json({
      error: 'Failed to generate risk priorities: ' + (error?.message || String(error)),
    });
  }
});

// Setup Vite in development or static serve in production
async function startServer() {
  const isProd = process.env.NODE_ENV === 'production';

  if (!isProd) {
    const { createServer: createViteServer } = await import('vite');
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: 'spa',
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.resolve(__dirname, 'dist');
    app.use(express.static(distPath));
    app.get('*', (_req: Request, res: Response) => {
      res.sendFile(path.resolve(distPath, 'index.html'));
    });
  }

  app.listen(PORT, '0.0.0.0', () => {
    console.log(`CiviTwin AI Server running at http://0.0.0.0:${PORT}`);
  });
}

startServer();
